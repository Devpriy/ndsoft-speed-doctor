=== NDsoft Speed Doctor ===
Contributors: ndsoftdesign
Tags: pagespeed, core web vitals, performance, lcp, cls
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 0.9.0-beta4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Diagnose PageSpeed and Core Web Vitals issues, apply opt-in safe fixes, and verify performance changes without an artificial score cap.

== Description ==

NDsoft Speed Doctor helps WordPress administrators understand PageSpeed/Lighthouse performance problems and safely apply common fixes.

The Free plugin provides real functionality. It does not intentionally limit a site to a particular PageSpeed score and does not require the Pro add-on to run scans or use the included safe fixes.

Free features include:

* Mobile and desktop PageSpeed Insights scans.
* Lighthouse lab metrics and available CrUX field data.
* Scan-result caching to reduce API quota usage.
* LCP request diagnostics and targeted image-priority fixes.
* Missing local image width/height detection and safe repair when dimensions can be verified.
* WordPress emoji asset cleanup.
* Before/after scan history and basic comparison.
* One-click safe-fix snapshots, cache purge, frontend validation, and rollback.
* Compatibility detection for Block Themes, Elementor, Divi, WooCommerce, WPBakery, Bricks, and common optimization plugins.
* Signed frontend asset inventory for diagnostic mapping of WordPress CSS/JS handles.
* Sanitized support report export. API keys and bearer tokens are not exported.

Some advanced opportunities may be shown as diagnostics in Free. An optional separately distributed Pro add-on can provide AI-assisted planning, controlled safe Auto Fix actions, conditional asset rules, and rollback. The premium code is not included in this WordPress.org package.

No plugin can guarantee a PageSpeed score. Results depend on hosting, theme/plugin architecture, page content, third-party scripts, traffic data, cache state, and external services.

== External services ==

= Google PageSpeed Insights API =

When an administrator explicitly runs a PageSpeed scan, the plugin sends the requested public page URL to the Google PageSpeed Insights API. If the administrator configures a PageSpeed API key, that key is also sent to Google for the API request. The plugin does not run these scans automatically in the Free edition.

Service information: https://developers.google.com/speed/docs/insights/v5/get-started
Google Terms: https://policies.google.com/terms
Google Privacy Policy: https://policies.google.com/privacy

== Installation ==

1. Upload `ndsoft-speed-doctor.zip` in Plugins > Add New > Upload Plugin, or install it from WordPress.org when available.
2. Activate NDsoft Speed Doctor.
3. Open Speed Doctor in the WordPress admin menu.
4. Optionally configure a Google PageSpeed Insights API key for more reliable API quota.
5. Run a baseline Mobile + Desktop scan.
6. Review each detected issue before applying a safe fix.
7. Run a fresh verification scan after changes.

== Frequently Asked Questions ==

= Does the Free version cap my PageSpeed score? =

No. Free fixes are not artificially limited by score. A lightweight site may already score very highly, while an older or heavier site may have advanced bottlenecks that require deeper work.

= Does activating the plugin change my site automatically? =

No. The plugin is safe-by-default. Performance changes are opt-in.

= Can it work with LiteSpeed Cache or WP Rocket? =

The plugin detects common optimization plugins and warns about overlapping features. Avoid enabling duplicate CSS/JS/cache optimizations in multiple plugins at the same time.

= Does the plugin guarantee 90+ or 100 PageSpeed? =

No. It helps identify and address measurable performance issues, but no specific score is guaranteed.

= What is NDsoft Speed Doctor Pro? =

Pro is an optional add-on distributed separately from the Free plugin. It is intended for deeper automation such as AI-assisted analysis, controlled safe Auto Fix workflows, conditional asset loading, and rollback. Free continues to work without Pro.

== Privacy ==

The Free plugin stores its settings, scan results, fix history, and diagnostic inventory in the site's WordPress database. It does not include telemetry or background tracking.

A PageSpeed API request is sent to Google only when an administrator runs a scan. See the External services section for the data sent and relevant policies.

== Changelog ==

= 0.9.0-beta4 =
* Market beta cleanup: aligned Free messaging with the focused Scan → Diagnose → Safe Fix → Verify workflow.
* Removed scheduled-monitoring references from the Free/Pro capability messaging.
* No change to the proven Free scan and low-risk fix engine.

= 0.9.0-beta3 =
* Compatibility release for NDsoft Speed Doctor Pro beta3 built-in Auto Fix.
* No new automatic Free-edition mutations; existing safe-by-default Free behavior is unchanged.

= 0.9.0-beta2 =
* Split the product into an independent Free core and a separate Pro add-on architecture.
* Kept PageSpeed scanning, common safe fixes, compatibility detection, asset diagnostics, validation, rollback, and support reporting in Free.
* Added extension hooks used by the optional Pro add-on without bundling premium execution code in Free.
* Added package and dependency hardening for release-candidate testing.

= 0.7.0 =
* Added frontend structural regression snapshots and rollback guard.
* Added compatibility and validation groundwork used during pre-release development.

= 0.6.0 =
* Added compatibility profiles for major builders, WooCommerce, and optimization plugins.
* Added signed frontend CSS/JS handle probe and render-blocking resource mapping.
* Switched manual script defer handling to WordPress dependency-aware strategy metadata.

= 0.5.0 =
* Added support-report hardening, secret masking, and stronger validation foundations.

= 0.3.0 =
* Added One-Click Safe Fix Engine, snapshots, cache purge, health validation, and rollback.

= 0.2.0 =
* Added PageSpeed caching, Lighthouse 13 diagnostics, exact LCP candidate detection, image dimension analysis, and scan history.

= 0.1.0 =
* Initial MVP with Mobile/Desktop scans and basic safe optimization controls.
