<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Free/Pro capability boundary.
 *
 * The free plugin ships the gate and extension hooks. A future Pro add-on can
 * unlock features through the ndssd_is_pro / ndssd_feature_available filters
 * without forking the core plugin.
 */
class NDSSD_Feature_Manager {
    public static function edition() {
        return self::is_pro() ? 'pro' : 'free';
    }

    public static function is_pro() {
        return (bool) apply_filters( 'ndssd_is_pro', false );
    }

    public static function has( $feature ) {
        $free = array(
            'pagespeed_scan',
            'diagnostics',
            'scan_cache',
            'lcp_safe_fix',
            'image_dimension_fix',
            'emoji_cleanup',
            'basic_rollback',
            'basic_comparison',
            'cache_purge',
        );

        $available = in_array( $feature, $free, true ) || self::is_pro();
        return (bool) apply_filters( 'ndssd_feature_available', $available, $feature, self::edition() );
    }


    /**
     * Advanced opportunities intentionally reserved for the Pro layer.
     * These are diagnostics only in Free; no score is guaranteed.
     */
    public static function advanced_opportunities( array $results ) {
        $map = array(
            'render_blocking' => array(
                'label'       => __( 'Render-blocking CSS/JS', 'ndsoft-speed-doctor' ),
                'description' => __( 'Dependency-aware loading, critical CSS, and safe deferral require deeper analysis.', 'ndsoft-speed-doctor' ),
            ),
            'long_tasks' => array(
                'label'       => __( 'Long main-thread tasks', 'ndsoft-speed-doctor' ),
                'description' => __( 'Find expensive JavaScript work and reduce or delay it without breaking interactions.', 'ndsoft-speed-doctor' ),
            ),
            'third_parties' => array(
                'label'       => __( 'Third-party script optimization', 'ndsoft-speed-doctor' ),
                'description' => __( 'Analyze analytics, chat, embeds, maps, video, and other third-party execution costs.', 'ndsoft-speed-doctor' ),
            ),
            'image_delivery' => array(
                'label'       => __( 'Advanced image delivery', 'ndsoft-speed-doctor' ),
                'description' => __( 'Handle responsive sources, format selection, delivery strategy, and page-specific image opportunities.', 'ndsoft-speed-doctor' ),
            ),
            'cls_culprits' => array(
                'label'       => __( 'CLS root-cause optimization', 'ndsoft-speed-doctor' ),
                'description' => __( 'Trace layout shifts to theme, block, embed, font, or JavaScript behavior.', 'ndsoft-speed-doctor' ),
            ),
            'network_tree' => array(
                'label'       => __( 'Critical request-chain optimization', 'ndsoft-speed-doctor' ),
                'description' => __( 'Reduce dependency chains and prioritize resources with dependency-aware changes.', 'ndsoft-speed-doctor' ),
            ),
            'cache_lifetime' => array(
                'label'       => __( 'Advanced cache lifetime tuning', 'ndsoft-speed-doctor' ),
                'description' => __( 'Review cache headers and ownership before recommending server, CDN, or application changes.', 'ndsoft-speed-doctor' ),
            ),
        );

        $found = array();
        foreach ( array( 'mobile', 'desktop' ) as $strategy ) {
            if ( empty( $results[ $strategy ]['diagnostics'] ) || ! is_array( $results[ $strategy ]['diagnostics'] ) ) {
                continue;
            }
            foreach ( $map as $key => $meta ) {
                if ( empty( $results[ $strategy ]['diagnostics'][ $key ] ) ) {
                    continue;
                }
                $diag = $results[ $strategy ]['diagnostics'][ $key ];
                $score = isset( $diag['score'] ) && is_numeric( $diag['score'] ) ? (float) $diag['score'] : null;
                $has_detail = ! empty( $diag['items'] ) || ! empty( $diag['display_value'] );
                if ( null !== $score && $score >= 0.9 ) {
                    continue;
                }
                if ( null === $score && ! $has_detail ) {
                    continue;
                }

                if ( ! isset( $found[ $key ] ) ) {
                    $found[ $key ] = array(
                        'id'          => $key,
                        'label'       => $meta['label'],
                        'description' => $meta['description'],
                        'strategies'  => array(),
                        'display'     => ! empty( $diag['display_value'] ) ? sanitize_text_field( $diag['display_value'] ) : '',
                    );
                }
                $found[ $key ]['strategies'][] = $strategy;
            }
        }

        foreach ( $found as &$item ) {
            $item['strategies'] = array_values( array_unique( $item['strategies'] ) );
        }
        unset( $item );
        return array_values( $found );
    }

    public static function optimization_summary( array $results, array $fixes ) {
        $free_total = 0;
        $free_active = 0;
        $free_remaining = 0;
        foreach ( $fixes as $fix ) {
            if ( ! empty( $fix['available'] ) || ! empty( $fix['active'] ) ) {
                $free_total++;
            }
            if ( ! empty( $fix['active'] ) ) {
                $free_active++;
            } elseif ( ! empty( $fix['available'] ) ) {
                $free_remaining++;
            }
        }

        return array(
            'mobile_score'          => isset( $results['mobile']['performance'] ) ? $results['mobile']['performance'] : null,
            'desktop_score'         => isset( $results['desktop']['performance'] ) ? $results['desktop']['performance'] : null,
            'free_total'            => $free_total,
            'free_active'           => $free_active,
            'free_remaining'        => $free_remaining,
            'advanced_opportunities'=> self::advanced_opportunities( $results ),
        );
    }

    public static function upgrade_url() {
        return esc_url_raw( apply_filters( 'ndssd_upgrade_url', 'https://ndsoftdesign.com/ndsoft-speed-doctor/' ) );
    }

    public static function pro_features() {
        return array(
            'ai_fix_plan'          => __( 'AI-assisted issue analysis', 'ndsoft-speed-doctor' ),
            'mcp_auto_fix'         => __( 'MCP-assisted code-level Auto Fix', 'ndsoft-speed-doctor' ),
            'conditional_assets'   => __( 'Conditional CSS/JS unloading', 'ndsoft-speed-doctor' ),
            'advanced_validation'  => __( 'Advanced regression and dependency validation', 'ndsoft-speed-doctor' ),
        );
    }
}
