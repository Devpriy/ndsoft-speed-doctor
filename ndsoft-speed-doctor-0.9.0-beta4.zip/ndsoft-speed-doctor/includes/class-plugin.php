<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class NDSSD_Plugin {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public static function defaults() {
        return array(
            'api_key'                    => '',
            'cache_minutes'              => 30,
            'disable_emojis'             => 0,
            'content_image_priority'     => 0,
            'preload_featured_image'     => 0,
            'defer_script_handles'       => '',
            'exact_lcp_priority'         => 0,
            'exact_lcp_url'              => '',
            'fix_local_image_dimensions' => 0,
            'edition'                    => 'free',
        );
    }

    public static function activate() {
        self::maybe_upgrade();
    }

    public static function maybe_upgrade() {
        $current = get_option( 'ndssd_settings', array() );
        update_option( 'ndssd_settings', wp_parse_args( is_array( $current ) ? $current : array(), self::defaults() ), false );
        update_option( 'ndssd_db_version', NDSSD_VERSION, false );
    }

    private function __construct() {
        self::maybe_upgrade();

        require_once NDSSD_DIR . 'includes/class-compatibility-manager.php';
        require_once NDSSD_DIR . 'includes/class-asset-inspector.php';
        require_once NDSSD_DIR . 'includes/class-frontend-validator.php';
        require_once NDSSD_DIR . 'includes/class-feature-manager.php';
        require_once NDSSD_DIR . 'includes/class-system-report.php';
        require_once NDSSD_DIR . 'includes/class-cache-manager.php';
        require_once NDSSD_DIR . 'includes/class-fix-engine.php';
        require_once NDSSD_DIR . 'includes/class-site-analyzer.php';
        require_once NDSSD_DIR . 'includes/class-pagespeed-client.php';
        require_once NDSSD_DIR . 'includes/class-optimizer.php';
        require_once NDSSD_DIR . 'admin/class-admin.php';

        new NDSSD_Asset_Inspector();
        new NDSSD_Optimizer();

        if ( is_admin() ) {
            new NDSSD_Admin();
        }
    }
}
