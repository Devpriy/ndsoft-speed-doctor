<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NDSSD_PageSpeed_Client {
    const ENDPOINT = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';


    public static function api_key() {
        if ( defined( 'NDSSD_PAGESPEED_API_KEY' ) && NDSSD_PAGESPEED_API_KEY ) {
            return sanitize_text_field( (string) NDSSD_PAGESPEED_API_KEY );
        }
        $settings = wp_parse_args( get_option( 'ndssd_settings', array() ), NDSSD_Plugin::defaults() );
        return ! empty( $settings['api_key'] ) ? sanitize_text_field( (string) $settings['api_key'] ) : '';
    }

    public static function api_key_source() {
        if ( defined( 'NDSSD_PAGESPEED_API_KEY' ) && NDSSD_PAGESPEED_API_KEY ) {
            return 'constant';
        }
        $settings = wp_parse_args( get_option( 'ndssd_settings', array() ), NDSSD_Plugin::defaults() );
        return ! empty( $settings['api_key'] ) ? 'option' : 'missing';
    }

    public function scan( $url, $strategy = 'mobile', $force = false ) {
        $strategy = in_array( $strategy, array( 'mobile', 'desktop' ), true ) ? $strategy : 'mobile';
        $settings = wp_parse_args( get_option( 'ndssd_settings', array() ), NDSSD_Plugin::defaults() );
        $cache_minutes = max( 5, min( 1440, (int) $settings['cache_minutes'] ) );
        $cache_key = $this->cache_key( $url, $strategy );

        if ( ! $force ) {
            $cached = get_transient( $cache_key );
            if ( is_array( $cached ) ) {
                $cached['cache_status'] = 'hit';
                return $cached;
            }
        }

        $args = array(
            'url'      => esc_url_raw( $url ),
            'strategy' => $strategy,
            'category' => 'performance',
        );

        $api_key = self::api_key();
        if ( '' !== $api_key ) {
            $args['key'] = $api_key;
        }

        $request_url = add_query_arg( $args, self::ENDPOINT );
        $response = wp_remote_get(
            $request_url,
            array(
                'timeout'     => 60,
                'redirection' => 3,
                'user-agent'  => 'NDsoft-Speed-Doctor/' . NDSSD_VERSION . '; ' . home_url( '/' ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $status = wp_remote_retrieve_response_code( $response );
        $body   = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( 200 !== (int) $status ) {
            $message = isset( $body['error']['message'] ) ? $body['error']['message'] : __( 'PageSpeed API request failed.', 'ndsoft-speed-doctor' );
            return new WP_Error( 'ndssd_pagespeed_api', sanitize_text_field( $message ), array( 'status' => $status ) );
        }

        if ( ! is_array( $body ) ) {
            return new WP_Error( 'ndssd_invalid_response', __( 'PageSpeed API returned an invalid response.', 'ndsoft-speed-doctor' ) );
        }

        $normalized = $this->normalize( $body, $url, $strategy );
        $normalized['cache_status'] = 'fresh';
        set_transient( $cache_key, $normalized, $cache_minutes * MINUTE_IN_SECONDS );
        return $normalized;
    }

    public function clear_cache( $url = '' ) {
        global $wpdb;
        $prefix = '_transient_ndssd_psi_';
        if ( $url ) {
            foreach ( array( 'mobile', 'desktop' ) as $strategy ) {
                delete_transient( $this->cache_key( $url, $strategy ) );
            }
            return;
        }

        // WordPress has no wildcard transient deletion API; restrict the SQL delete to this plugin's namespaced keys.
        $like = $wpdb->esc_like( $prefix ) . '%';
        $timeout_like = $wpdb->esc_like( '_transient_timeout_ndssd_psi_' ) . '%';
        $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $like, $timeout_like ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
    }

    private function cache_key( $url, $strategy ) {
        return 'ndssd_psi_' . md5( strtolower( untrailingslashit( esc_url_raw( $url ) ) ) . '|' . $strategy );
    }

    private function normalize( array $data, $url, $strategy ) {
        $lighthouse = isset( $data['lighthouseResult'] ) && is_array( $data['lighthouseResult'] ) ? $data['lighthouseResult'] : array();
        $audits     = isset( $lighthouse['audits'] ) && is_array( $lighthouse['audits'] ) ? $lighthouse['audits'] : array();
        $categories = isset( $lighthouse['categories'] ) && is_array( $lighthouse['categories'] ) ? $lighthouse['categories'] : array();

        $score = null;
        if ( isset( $categories['performance']['score'] ) && is_numeric( $categories['performance']['score'] ) ) {
            $score = (int) round( (float) $categories['performance']['score'] * 100 );
        }

        $lab_ids = array(
            'first-contentful-paint'      => 'FCP',
            'largest-contentful-paint'    => 'LCP',
            'interaction-to-next-paint'   => 'INP',
            'total-blocking-time'         => 'TBT',
            'cumulative-layout-shift'     => 'CLS',
            'speed-index'                 => 'Speed Index',
        );

        $lab = array();
        foreach ( $lab_ids as $audit_id => $label ) {
            if ( ! isset( $audits[ $audit_id ] ) || ! is_array( $audits[ $audit_id ] ) ) {
                continue;
            }
            $audit = $audits[ $audit_id ];
            $lab[ $audit_id ] = array(
                'label'         => $label,
                'display_value' => isset( $audit['displayValue'] ) ? sanitize_text_field( $audit['displayValue'] ) : '—',
                'numeric_value' => isset( $audit['numericValue'] ) && is_numeric( $audit['numericValue'] ) ? (float) $audit['numericValue'] : null,
                'score'         => isset( $audit['score'] ) && is_numeric( $audit['score'] ) ? (float) $audit['score'] : null,
            );
        }

        $field = $this->extract_field_metrics( isset( $data['loadingExperience']['metrics'] ) ? $data['loadingExperience']['metrics'] : array() );
        $origin_field = $this->extract_field_metrics( isset( $data['originLoadingExperience']['metrics'] ) ? $data['originLoadingExperience']['metrics'] : array() );

        $recommendations = array();
        foreach ( $audits as $audit_id => $audit ) {
            if ( ! is_array( $audit ) || empty( $audit['title'] ) ) {
                continue;
            }
            $score_value = isset( $audit['score'] ) && is_numeric( $audit['score'] ) ? (float) $audit['score'] : null;
            $details_type = isset( $audit['details']['type'] ) ? $audit['details']['type'] : '';
            $savings = isset( $audit['details']['overallSavingsMs'] ) && is_numeric( $audit['details']['overallSavingsMs'] ) ? (float) $audit['details']['overallSavingsMs'] : 0;

            if ( 'opportunity' !== $details_type && ( null === $score_value || $score_value >= 0.9 ) ) {
                continue;
            }
            if ( isset( $lab_ids[ $audit_id ] ) ) {
                continue;
            }

            $recommendations[] = array(
                'id'            => sanitize_key( $audit_id ),
                'title'         => sanitize_text_field( $audit['title'] ),
                'display_value' => isset( $audit['displayValue'] ) ? sanitize_text_field( $audit['displayValue'] ) : '',
                'score'         => $score_value,
                'savings_ms'    => $savings,
            );
        }

        usort(
            $recommendations,
            static function ( $a, $b ) {
                if ( $a['savings_ms'] === $b['savings_ms'] ) {
                    return ( $a['score'] ?? 1 ) <=> ( $b['score'] ?? 1 );
                }
                return $b['savings_ms'] <=> $a['savings_ms'];
            }
        );

        $diagnostic_map = array(
            'lcp_discovery'    => array( 'lcp-discovery-insight', 'prioritize-lcp-image', 'lcp-lazy-loaded' ),
            'lcp_phases'       => array( 'lcp-phases-insight', 'largest-contentful-paint-element' ),
            'render_blocking'  => array( 'render-blocking-insight', 'render-blocking-resources' ),
            'unsized_images'   => array( 'unsized-images' ),
            'cache_lifetime'   => array( 'use-cache-insight', 'uses-long-cache-ttl' ),
            'long_tasks'       => array( 'long-tasks' ),
            'third_parties'    => array( 'third-parties-insight', 'third-party-summary' ),
            'image_delivery'   => array( 'image-delivery-insight', 'uses-optimized-images', 'uses-responsive-images', 'modern-image-formats' ),
            'cls_culprits'     => array( 'cls-culprits-insight', 'layout-shifts' ),
            'network_tree'     => array( 'network-dependency-tree-insight', 'critical-request-chains' ),
        );

        $diagnostics = array();
        foreach ( $diagnostic_map as $key => $ids ) {
            $diagnostic = $this->first_audit( $audits, $ids );
            if ( $diagnostic ) {
                $diagnostics[ $key ] = $diagnostic;
            }
        }

        $lcp_candidate = $this->extract_lcp_candidate( $audits );

        return array(
            'url'             => esc_url_raw( $url ),
            'strategy'        => $strategy,
            'fetched_at'      => current_time( 'mysql' ),
            'performance'     => $score,
            'lab'             => $lab,
            'field'           => $field,
            'origin_field'    => $origin_field,
            'recommendations' => array_slice( $recommendations, 0, 12 ),
            'diagnostics'     => $diagnostics,
            'lcp_candidate'   => $lcp_candidate,
            'lighthouse'      => array(
                'version' => isset( $lighthouse['lighthouseVersion'] ) ? sanitize_text_field( $lighthouse['lighthouseVersion'] ) : '',
                'final_url' => isset( $lighthouse['finalDisplayedUrl'] ) ? esc_url_raw( $lighthouse['finalDisplayedUrl'] ) : ( isset( $lighthouse['finalUrl'] ) ? esc_url_raw( $lighthouse['finalUrl'] ) : '' ),
            ),
        );
    }

    private function first_audit( array $audits, array $ids ) {
        foreach ( $ids as $id ) {
            if ( isset( $audits[ $id ] ) && is_array( $audits[ $id ] ) ) {
                return $this->audit_summary( $id, $audits[ $id ] );
            }
        }
        return array();
    }

    private function audit_summary( $id, array $audit ) {
        $score = isset( $audit['score'] ) && is_numeric( $audit['score'] ) ? (float) $audit['score'] : null;
        $items = array();
        if ( isset( $audit['details'] ) && is_array( $audit['details'] ) ) {
            $items = $this->collect_detail_items( $audit['details'] );
        }

        return array(
            'id'            => sanitize_key( $id ),
            'title'         => isset( $audit['title'] ) ? sanitize_text_field( $audit['title'] ) : $id,
            'description'   => isset( $audit['description'] ) ? $this->clean_markdown( $audit['description'] ) : '',
            'display_value' => isset( $audit['displayValue'] ) ? sanitize_text_field( $audit['displayValue'] ) : '',
            'score'         => $score,
            'items'         => array_slice( $items, 0, 12 ),
        );
    }

    private function collect_detail_items( array $details ) {
        $found = array();
        $this->walk_details( $details, $found );
        $unique = array();
        $seen = array();
        foreach ( $found as $item ) {
            $fingerprint = md5( wp_json_encode( $item ) );
            if ( isset( $seen[ $fingerprint ] ) ) {
                continue;
            }
            $seen[ $fingerprint ] = true;
            $unique[] = $item;
            if ( count( $unique ) >= 20 ) {
                break;
            }
        }
        return $unique;
    }

    private function walk_details( $value, array &$found ) {
        if ( count( $found ) >= 30 || ! is_array( $value ) ) {
            return;
        }

        $candidate = array();
        foreach ( array( 'url', 'src' ) as $key ) {
            if ( ! empty( $value[ $key ] ) && is_string( $value[ $key ] ) && preg_match( '#^https?://#i', $value[ $key ] ) ) {
                $candidate['url'] = esc_url_raw( $value[ $key ] );
                break;
            }
        }
        if ( isset( $value['wastedMs'] ) && is_numeric( $value['wastedMs'] ) ) {
            $candidate['wasted_ms'] = (float) $value['wastedMs'];
        }
        if ( isset( $value['wastedBytes'] ) && is_numeric( $value['wastedBytes'] ) ) {
            $candidate['wasted_bytes'] = (int) $value['wastedBytes'];
        }
        if ( isset( $value['totalBytes'] ) && is_numeric( $value['totalBytes'] ) ) {
            $candidate['total_bytes'] = (int) $value['totalBytes'];
        }
        if ( isset( $value['node'] ) && is_array( $value['node'] ) ) {
            if ( ! empty( $value['node']['snippet'] ) ) {
                $candidate['snippet'] = substr( wp_check_invalid_utf8( (string) $value['node']['snippet'] ), 0, 1000 );
            }
            if ( ! empty( $value['node']['selector'] ) ) {
                $candidate['selector'] = sanitize_text_field( $value['node']['selector'] );
            }
        }
        if ( ! empty( $value['snippet'] ) && is_string( $value['snippet'] ) ) {
            $candidate['snippet'] = substr( wp_check_invalid_utf8( (string) $value['snippet'] ), 0, 1000 );
        }
        if ( ! empty( $value['selector'] ) && is_string( $value['selector'] ) ) {
            $candidate['selector'] = sanitize_text_field( $value['selector'] );
        }

        if ( $candidate ) {
            $found[] = $candidate;
        }

        foreach ( $value as $child ) {
            if ( is_array( $child ) ) {
                $this->walk_details( $child, $found );
            }
        }
    }

    private function extract_lcp_candidate( array $audits ) {
        $ids = array( 'lcp-discovery-insight', 'lcp-phases-insight', 'prioritize-lcp-image', 'lcp-lazy-loaded', 'largest-contentful-paint-element' );
        $candidate = array( 'url' => '', 'snippet' => '', 'selector' => '' );

        foreach ( $ids as $id ) {
            if ( empty( $audits[ $id ] ) || ! is_array( $audits[ $id ] ) ) {
                continue;
            }
            $items = $this->collect_detail_items( isset( $audits[ $id ]['details'] ) && is_array( $audits[ $id ]['details'] ) ? $audits[ $id ]['details'] : array() );
            foreach ( $items as $item ) {
                if ( empty( $candidate['snippet'] ) && ! empty( $item['snippet'] ) ) {
                    $candidate['snippet'] = $item['snippet'];
                    if ( preg_match( '/\bsrc=["\']([^"\']+)["\']/i', html_entity_decode( $item['snippet'], ENT_QUOTES, 'UTF-8' ), $m ) ) {
                        $candidate['url'] = esc_url_raw( $m[1] );
                    }
                }
                if ( empty( $candidate['selector'] ) && ! empty( $item['selector'] ) ) {
                    $candidate['selector'] = $item['selector'];
                }
                if ( empty( $candidate['url'] ) && ! empty( $item['url'] ) && preg_match( '/\.(?:avif|webp|png|jpe?g|gif|svg)(?:[?#]|$)/i', $item['url'] ) ) {
                    $candidate['url'] = $item['url'];
                }
            }
            if ( ! empty( $candidate['url'] ) ) {
                break;
            }
        }

        if ( empty( $candidate['url'] ) && empty( $candidate['snippet'] ) && empty( $candidate['selector'] ) ) {
            return array();
        }
        return $candidate;
    }

    private function clean_markdown( $text ) {
        $text = preg_replace( '/\[([^\]]+)\]\([^\)]+\)/', '$1', (string) $text );
        $text = str_replace( array( '`', '**', '__' ), '', $text );
        return sanitize_text_field( wp_strip_all_tags( $text ) );
    }

    private function extract_field_metrics( $metrics ) {
        if ( ! is_array( $metrics ) ) {
            return array();
        }

        $map = array(
            'LARGEST_CONTENTFUL_PAINT_MS'   => 'LCP',
            'INTERACTION_TO_NEXT_PAINT'     => 'INP',
            'INTERACTION_TO_NEXT_PAINT_MS'  => 'INP',
            'CUMULATIVE_LAYOUT_SHIFT_SCORE' => 'CLS',
            'FIRST_CONTENTFUL_PAINT_MS'     => 'FCP',
        );

        $out = array();
        foreach ( $map as $key => $label ) {
            if ( ! isset( $metrics[ $key ] ) || ! is_array( $metrics[ $key ] ) ) {
                continue;
            }
            $metric = $metrics[ $key ];
            $out[ $label ] = array(
                'percentile' => isset( $metric['percentile'] ) && is_numeric( $metric['percentile'] ) ? (float) $metric['percentile'] : null,
                'category'   => isset( $metric['category'] ) ? sanitize_key( strtolower( $metric['category'] ) ) : '',
            );
        }
        return $out;
    }
}
