<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Captures the actual WordPress style/script handles rendered on a frontend URL.
 * A short-lived signed probe prevents exposing the inventory publicly by default.
 */
class NDSSD_Asset_Inspector {
    const OPTION = 'ndssd_last_asset_inventory';
    const TOKEN_PREFIX = 'ndssd_asset_probe_';

    public function __construct() {
        add_action( 'send_headers', array( $this, 'send_probe_nocache_headers' ), 0 );
        add_action( 'shutdown', array( $this, 'emit_probe_payload' ), PHP_INT_MAX );
    }


    public function send_probe_nocache_headers() {
        $token = isset( $_GET['__ndssd_asset_probe'] ) ? sanitize_text_field( wp_unslash( $_GET['__ndssd_asset_probe'] ) ) : '';
        if ( $token && 1 === (int) get_transient( self::TOKEN_PREFIX . $token ) ) {
            nocache_headers();
            header( 'X-Robots-Tag: noindex, nofollow, noarchive', true );
        }
    }

    public static function probe( $url ) {
        $url = esc_url_raw( $url );
        if ( ! $url || ! self::is_same_site_url( $url ) ) {
            return new WP_Error( 'ndssd_asset_probe_url', __( 'Asset probing is limited to this WordPress site.', 'ndsoft-speed-doctor' ) );
        }

        $token = wp_generate_password( 24, false, false );
        set_transient( self::TOKEN_PREFIX . $token, 1, MINUTE_IN_SECONDS );
        $probe_url = add_query_arg( '__ndssd_asset_probe', $token, $url );
        $response = wp_safe_remote_get(
            $probe_url,
            array(
                'timeout'     => 25,
                'redirection' => 2,
                'user-agent'  => 'NDsoft-Speed-Doctor-Asset-Probe/' . NDSSD_VERSION,
                'headers'     => array( 'Cache-Control' => 'no-cache' ),
            )
        );
        delete_transient( self::TOKEN_PREFIX . $token );

        if ( is_wp_error( $response ) ) {
            return $response;
        }
        $status = (int) wp_remote_retrieve_response_code( $response );
        $body   = (string) wp_remote_retrieve_body( $response );
        if ( $status < 200 || $status >= 400 ) {
            return new WP_Error( 'ndssd_asset_probe_http', sprintf( __( 'Asset probe returned HTTP %d.', 'ndsoft-speed-doctor' ), $status ) );
        }
        if ( ! preg_match( '/<!--NDSSD_ASSET_PROBE:([A-Za-z0-9%._~-]+)-->/m', $body, $match ) ) {
            return new WP_Error( 'ndssd_asset_probe_missing', __( 'The frontend did not return the Speed Doctor asset probe marker. The theme may omit normal shutdown output or a cache may have served an older page.', 'ndsoft-speed-doctor' ) );
        }
        $json = rawurldecode( $match[1] );
        $data = $json ? json_decode( $json, true ) : null;
        if ( ! is_array( $data ) ) {
            return new WP_Error( 'ndssd_asset_probe_decode', __( 'The asset probe payload could not be decoded.', 'ndsoft-speed-doctor' ) );
        }
        $data['url'] = $url;
        $data['captured_at'] = current_time( 'mysql' );
        update_option( self::OPTION, $data, false );
        return $data;
    }

    public function emit_probe_payload() {
        if ( is_admin() || wp_doing_ajax() ) {
            return;
        }
        $token = isset( $_GET['__ndssd_asset_probe'] ) ? sanitize_text_field( wp_unslash( $_GET['__ndssd_asset_probe'] ) ) : '';
        if ( ! $token || 1 !== (int) get_transient( self::TOKEN_PREFIX . $token ) ) {
            return;
        }
        delete_transient( self::TOKEN_PREFIX . $token );

        $payload = array(
            'styles'  => self::collect( wp_styles(), 'style' ),
            'scripts' => self::collect( wp_scripts(), 'script' ),
        );
        $json = wp_json_encode( $payload );
        if ( $json ) {
            echo "\n<!--NDSSD_ASSET_PROBE:" . esc_html( rawurlencode( $json ) ) . "-->\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
    }

    public static function find_by_url( $url, array $inventory ) {
        $needle = self::normalize_resource_url( $url );
        if ( ! $needle ) {
            return array();
        }
        foreach ( array( 'styles', 'scripts' ) as $bucket ) {
            if ( empty( $inventory[ $bucket ] ) || ! is_array( $inventory[ $bucket ] ) ) {
                continue;
            }
            foreach ( $inventory[ $bucket ] as $asset ) {
                if ( ! empty( $asset['src'] ) && self::normalize_resource_url( $asset['src'] ) === $needle ) {
                    return $asset;
                }
            }
        }
        return array();
    }

    private static function collect( $registry, $type ) {
        if ( ! is_object( $registry ) || empty( $registry->registered ) ) {
            return array();
        }
        $handles = array_values( array_unique( array_merge( (array) $registry->done, (array) $registry->queue ) ) );
        $out = array();
        foreach ( $handles as $handle ) {
            if ( empty( $registry->registered[ $handle ] ) ) {
                continue;
            }
            $obj = $registry->registered[ $handle ];
            $src = isset( $obj->src ) ? self::absolute_resource_url( (string) $obj->src ) : '';
            if ( ! $src ) {
                continue;
            }
            $out[] = array(
                'handle' => sanitize_key( $handle ),
                'type'   => $type,
                'src'    => esc_url_raw( $src ),
                'deps'   => array_values( array_map( 'sanitize_key', isset( $obj->deps ) ? (array) $obj->deps : array() ) ),
                'state'  => in_array( $handle, (array) $registry->done, true ) ? 'printed' : 'queued',
                'owner'  => self::owner_from_url( $src ),
            );
        }
        return $out;
    }

    private static function absolute_resource_url( $src ) {
        if ( ! $src ) {
            return '';
        }
        if ( preg_match( '#^https?://#i', $src ) ) {
            return $src;
        }
        if ( 0 === strpos( $src, '//' ) ) {
            return ( is_ssl() ? 'https:' : 'http:' ) . $src;
        }
        if ( 0 === strpos( $src, '/' ) ) {
            return home_url( $src );
        }
        return content_url( '/' . ltrim( $src, '/' ) );
    }

    private static function normalize_resource_url( $url ) {
        $url = preg_replace( '/[?#].*$/', '', html_entity_decode( (string) $url, ENT_QUOTES, 'UTF-8' ) );
        if ( 0 === strpos( $url, '//' ) ) {
            $url = ( is_ssl() ? 'https:' : 'http:' ) . $url;
        }
        $parts = wp_parse_url( $url );
        if ( empty( $parts['host'] ) || empty( $parts['path'] ) ) {
            return '';
        }
        return strtolower( $parts['host'] ) . rawurldecode( $parts['path'] );
    }

    private static function owner_from_url( $url ) {
        $path = (string) wp_parse_url( $url, PHP_URL_PATH );
        if ( preg_match( '#/wp-content/plugins/([^/]+)/#', $path, $m ) ) {
            return 'plugin:' . sanitize_key( $m[1] );
        }
        if ( preg_match( '#/wp-content/themes/([^/]+)/#', $path, $m ) ) {
            return 'theme:' . sanitize_key( $m[1] );
        }
        if ( false !== strpos( $path, '/wp-includes/' ) ) {
            return 'wordpress-core';
        }
        return 'other';
    }

    private static function is_same_site_url( $url ) {
        $a = wp_parse_url( $url );
        $b = wp_parse_url( home_url( '/' ) );
        return ! empty( $a['host'] ) && ! empty( $b['host'] ) && strtolower( $a['host'] ) === strtolower( $b['host'] ) && in_array( strtolower( $a['scheme'] ?? '' ), array( 'http', 'https' ), true );
    }
}
