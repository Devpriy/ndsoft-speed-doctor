<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NDSSD_Cache_Manager {
    public static function purge() {
        $purged = array();

        // LiteSpeed Cache publishes this action for full cache purge.
        if ( defined( 'LSCWP_V' ) || has_action( 'litespeed_purge_all' ) ) {
            do_action( 'litespeed_purge_all' );
            $purged[] = 'LiteSpeed Cache';
        }

        if ( function_exists( 'rocket_clean_domain' ) ) {
            rocket_clean_domain();
            $purged[] = 'WP Rocket';
        }

        if ( function_exists( 'w3tc_flush_all' ) ) {
            w3tc_flush_all();
            $purged[] = 'W3 Total Cache';
        }

        if ( has_action( 'autoptimize_action_cachepurged' ) ) {
            do_action( 'autoptimize_action_cachepurged' );
            $purged[] = 'Autoptimize';
        }

        wp_cache_flush();
        $purged[] = __( 'WordPress object cache', 'ndsoft-speed-doctor' );

        return array_values( array_unique( $purged ) );
    }
}
