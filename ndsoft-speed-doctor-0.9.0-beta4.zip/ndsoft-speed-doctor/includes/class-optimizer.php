<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NDSSD_Optimizer {
    private $settings = array();

    public function __construct() {
        $this->settings = wp_parse_args( get_option( 'ndssd_settings', array() ), NDSSD_Plugin::defaults() );

        if ( ! empty( $this->settings['disable_emojis'] ) ) {
            add_action( 'init', array( $this, 'disable_emojis' ) );
        }

        if ( ! empty( $this->settings['content_image_priority'] ) ) {
            add_filter( 'the_content', array( $this, 'optimize_content_images' ), 20 );
        }

        if ( ! empty( $this->settings['preload_featured_image'] ) ) {
            add_action( 'wp_head', array( $this, 'preload_featured_image' ), 2 );
        }

        if ( ! empty( $this->settings['defer_script_handles'] ) ) {
            add_action( 'wp_enqueue_scripts', array( $this, 'apply_defer_strategies' ), PHP_INT_MAX );
            add_action( 'wp_print_footer_scripts', array( $this, 'apply_defer_strategies' ), 18 );
        }

        if ( ! empty( $this->settings['exact_lcp_priority'] ) || ! empty( $this->settings['fix_local_image_dimensions'] ) ) {
            add_action( 'template_redirect', array( $this, 'start_html_optimizer' ), 0 );
        }
    }

    public function disable_emojis() {
        remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
        remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
        remove_action( 'wp_print_styles', 'print_emoji_styles' );
        remove_action( 'admin_print_styles', 'print_emoji_styles' );
        remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
        remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
        remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
    }

    public function optimize_content_images( $content ) {
        if ( is_admin() || is_feed() || ! is_singular() || false === stripos( $content, '<img' ) ) {
            return $content;
        }

        if ( class_exists( 'WP_HTML_Tag_Processor' ) ) {
            $processor = new WP_HTML_Tag_Processor( $content );
            $index = 0;
            while ( $processor->next_tag( 'img' ) ) {
                if ( 0 === $index ) {
                    $processor->set_attribute( 'loading', 'eager' );
                    $processor->set_attribute( 'fetchpriority', 'high' );
                    $processor->set_attribute( 'decoding', 'async' );
                } else {
                    if ( ! $processor->get_attribute( 'loading' ) ) {
                        $processor->set_attribute( 'loading', 'lazy' );
                    }
                    if ( ! $processor->get_attribute( 'decoding' ) ) {
                        $processor->set_attribute( 'decoding', 'async' );
                    }
                }
                $index++;
            }
            return $processor->get_updated_html();
        }

        return preg_replace_callback(
            '/<img\b([^>]*)>/i',
            static function ( $matches ) {
                $attrs = $matches[1];
                $attrs = preg_replace( '/\sloading=("|\')[^"\']*\1/i', '', $attrs );
                if ( false === stripos( $attrs, 'fetchpriority=' ) ) {
                    $attrs .= ' fetchpriority="high"';
                }
                if ( false === stripos( $attrs, 'decoding=' ) ) {
                    $attrs .= ' decoding="async"';
                }
                return '<img' . $attrs . ' loading="eager">';
            },
            $content,
            1
        );
    }

    public function preload_featured_image() {
        if ( ! is_singular() ) {
            return;
        }

        $post_id = get_queried_object_id();
        if ( ! $post_id || ! has_post_thumbnail( $post_id ) ) {
            return;
        }

        $image_id = get_post_thumbnail_id( $post_id );
        $src = wp_get_attachment_image_url( $image_id, 'full' );
        if ( ! $src ) {
            return;
        }

        $srcset = wp_get_attachment_image_srcset( $image_id, 'full' );
        $sizes  = wp_get_attachment_image_sizes( $image_id, 'full' );

        echo "\n<link rel=\"preload\" as=\"image\" href=\"" . esc_url( $src ) . "\"";
        if ( $srcset ) {
            echo ' imagesrcset="' . esc_attr( $srcset ) . '"';
        }
        if ( $sizes ) {
            echo ' imagesizes="' . esc_attr( $sizes ) . '"';
        }
        echo " fetchpriority=\"high\">\n";
    }

    public function apply_defer_strategies() {
        $handles = array_filter( array_map( 'sanitize_key', preg_split( '/[\s,]+/', (string) $this->settings['defer_script_handles'] ) ) );
        foreach ( $handles as $handle ) {
            if ( wp_script_is( $handle, 'registered' ) || wp_script_is( $handle, 'enqueued' ) ) {
                // WordPress resolves the eligible strategy across the dependency tree.
                wp_script_add_data( $handle, 'strategy', 'defer' );
            }
        }
    }

    public function start_html_optimizer() {
        if ( is_admin() || is_feed() || is_robots() || is_trackback() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
            return;
        }
        ob_start( array( $this, 'optimize_final_html' ) );
    }

    public function optimize_final_html( $html ) {
        if ( ! is_string( $html ) || false === stripos( $html, '<img' ) ) {
            return $html;
        }

        if ( ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
            return $html;
        }

        $exact_lcp = ! empty( $this->settings['exact_lcp_priority'] ) && ! empty( $this->settings['exact_lcp_url'] );
        $fix_dims  = ! empty( $this->settings['fix_local_image_dimensions'] );
        $processor = new WP_HTML_Tag_Processor( $html );
        $lcp_done  = false;

        while ( $processor->next_tag( 'img' ) ) {
            $src = (string) $processor->get_attribute( 'src' );
            if ( '' === $src ) {
                continue;
            }

            if ( $exact_lcp && ! $lcp_done && NDSSD_Site_Analyzer::urls_equivalent( $src, $this->settings['exact_lcp_url'] ) ) {
                $processor->set_attribute( 'fetchpriority', 'high' );
                $processor->set_attribute( 'loading', 'eager' );
                if ( ! $processor->get_attribute( 'decoding' ) ) {
                    $processor->set_attribute( 'decoding', 'async' );
                }
                $lcp_done = true;
            }

            if ( $fix_dims && ( ! $processor->get_attribute( 'width' ) || ! $processor->get_attribute( 'height' ) ) ) {
                $dims = NDSSD_Site_Analyzer::local_image_dimensions( $src );
                if ( $dims ) {
                    if ( ! $processor->get_attribute( 'width' ) ) {
                        $processor->set_attribute( 'width', (string) $dims[0] );
                    }
                    if ( ! $processor->get_attribute( 'height' ) ) {
                        $processor->set_attribute( 'height', (string) $dims[1] );
                    }
                }
            }
        }

        return $processor->get_updated_html();
    }
}
