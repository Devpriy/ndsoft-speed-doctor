<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Lightweight server-side regression guard. It does not replace a real browser
 * visual test, but catches HTTP failures and unexpected structural changes.
 */
class NDSSD_Frontend_Validator {
    public static function snapshot( $url ) {
        $url = esc_url_raw( $url );
        $response = wp_safe_remote_get(
            $url,
            array(
                'timeout'     => 20,
                'redirection' => 2,
                'headers'     => array( 'Cache-Control' => 'no-cache' ),
                'user-agent'  => 'NDsoft-Speed-Doctor-Validator/' . NDSSD_VERSION,
            )
        );
        if ( is_wp_error( $response ) ) {
            return $response;
        }
        $status = (int) wp_remote_retrieve_response_code( $response );
        $html   = (string) wp_remote_retrieve_body( $response );
        if ( $status < 200 || $status >= 400 || strlen( trim( $html ) ) < 100 ) {
            return new WP_Error( 'ndssd_validation_http', sprintf( __( 'Frontend validation returned HTTP %d or unexpectedly little HTML.', 'ndsoft-speed-doctor' ), $status ) );
        }
        if ( false !== stripos( $html, 'There has been a critical error on this website' ) ) {
            return new WP_Error( 'ndssd_validation_critical', __( 'WordPress returned a critical-error page.', 'ndsoft-speed-doctor' ) );
        }

        $visible = preg_replace( '#<(script|style|noscript|template)\b[^>]*>.*?</\1>#is', ' ', $html );
        $visible = wp_strip_all_tags( (string) $visible, true );
        $visible = preg_replace( '/\s+/u', ' ', $visible );
        $visible = trim( (string) $visible );

        return array(
            'status'       => $status,
            'bytes'        => strlen( $html ),
            'visible_chars'=> strlen( $visible ),
            'h1'           => preg_match_all( '/<h1\b/i', $html ),
            'h2'           => preg_match_all( '/<h2\b/i', $html ),
            'forms'        => preg_match_all( '/<form\b/i', $html ),
            'navs'         => preg_match_all( '/<nav\b/i', $html ),
            'images'       => preg_match_all( '/<img\b/i', $html ),
            'links'        => preg_match_all( '/<a\b/i', $html ),
            'scripts'      => preg_match_all( '/<script\b/i', $html ),
            'stylesheets'  => preg_match_all( '/<link\b[^>]*rel=["\'][^"\']*stylesheet/i', $html ),
        );
    }

    public static function compare( array $before, array $after ) {
        $critical = array();
        $warnings = array();
        foreach ( array( 'h1', 'forms', 'navs', 'images' ) as $key ) {
            $a = isset( $before[ $key ] ) ? (int) $before[ $key ] : 0;
            $b = isset( $after[ $key ] ) ? (int) $after[ $key ] : 0;
            if ( $a !== $b ) {
                $critical[] = sprintf( '%s count changed %d → %d', $key, $a, $b );
            }
        }
        $before_chars = max( 1, isset( $before['visible_chars'] ) ? (int) $before['visible_chars'] : 1 );
        $after_chars  = isset( $after['visible_chars'] ) ? (int) $after['visible_chars'] : 0;
        $ratio = $after_chars / $before_chars;
        if ( $ratio < 0.85 || $ratio > 1.15 ) {
            $critical[] = sprintf( 'visible content size changed by %s%%', number_format_i18n( abs( 1 - $ratio ) * 100, 1 ) );
        }
        foreach ( array( 'scripts', 'stylesheets', 'links', 'h2' ) as $key ) {
            $a = isset( $before[ $key ] ) ? (int) $before[ $key ] : 0;
            $b = isset( $after[ $key ] ) ? (int) $after[ $key ] : 0;
            if ( abs( $a - $b ) > max( 2, (int) ceil( max( 1, $a ) * 0.25 ) ) ) {
                $warnings[] = sprintf( '%s count changed %d → %d', $key, $a, $b );
            }
        }

        return array(
            'passed'   => empty( $critical ),
            'critical' => $critical,
            'warnings' => $warnings,
            'before'   => $before,
            'after'    => $after,
        );
    }
}
