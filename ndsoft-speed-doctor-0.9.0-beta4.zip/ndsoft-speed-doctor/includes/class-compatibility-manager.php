<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Detects common builders, commerce layers, and optimization plugins without
 * changing their configuration. Profiles are advisory and version-aware.
 */
class NDSSD_Compatibility_Manager {
    public static function active_plugins() {
        $active = (array) get_option( 'active_plugins', array() );
        if ( is_multisite() ) {
            $active = array_unique( array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) ) );
        }
        return array_values( $active );
    }

    public static function profiles() {
        $active = self::active_plugins();
        $theme  = wp_get_theme();
        $template = strtolower( (string) $theme->get_template() );
        $stylesheet = strtolower( (string) $theme->get_stylesheet() );
        $profiles = array();

        $profiles[] = self::profile(
            'block_theme',
            __( 'Block Theme / Site Editor', 'ndsoft-speed-doctor' ),
            function_exists( 'wp_is_block_theme' ) && wp_is_block_theme(),
            get_bloginfo( 'version' ),
            __( 'Prefer block-aware fixes and avoid rewriting generated block markup or global styles.', 'ndsoft-speed-doctor' )
        );
        $profiles[] = self::profile(
            'elementor',
            'Elementor',
            in_array( 'elementor/elementor.php', $active, true ) || defined( 'ELEMENTOR_VERSION' ),
            defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : self::plugin_version( 'elementor/elementor.php' ),
            __( 'Keep Elementor frontend/runtime handles protected unless a rule is explicitly reviewed.', 'ndsoft-speed-doctor' )
        );
        $profiles[] = self::profile(
            'elementor_pro',
            'Elementor Pro',
            in_array( 'elementor-pro/elementor-pro.php', $active, true ) || defined( 'ELEMENTOR_PRO_VERSION' ),
            defined( 'ELEMENTOR_PRO_VERSION' ) ? ELEMENTOR_PRO_VERSION : self::plugin_version( 'elementor-pro/elementor-pro.php' ),
            __( 'Dynamic widgets, forms, popups, and theme-builder assets may be page dependent.', 'ndsoft-speed-doctor' )
        );
        $profiles[] = self::profile(
            'divi',
            'Divi',
            false !== strpos( $template, 'divi' ) || false !== strpos( $stylesheet, 'divi' ) || in_array( 'divi-builder/divi-builder.php', $active, true ),
            self::plugin_version( 'divi-builder/divi-builder.php' ),
            __( 'Treat generated builder CSS/JS as dependency-sensitive and verify visual output after changes.', 'ndsoft-speed-doctor' )
        );
        $profiles[] = self::profile(
            'woocommerce',
            'WooCommerce',
            in_array( 'woocommerce/woocommerce.php', $active, true ) || class_exists( 'WooCommerce' ),
            defined( 'WC_VERSION' ) ? WC_VERSION : self::plugin_version( 'woocommerce/woocommerce.php' ),
            __( 'Cart, checkout, account, fragments, payment, variation, and gallery assets are protected contexts.', 'ndsoft-speed-doctor' )
        );
        $profiles[] = self::profile(
            'wpbakery',
            'WPBakery Page Builder',
            in_array( 'js_composer/js_composer.php', $active, true ) || defined( 'WPB_VC_VERSION' ),
            defined( 'WPB_VC_VERSION' ) ? WPB_VC_VERSION : self::plugin_version( 'js_composer/js_composer.php' ),
            __( 'Shortcode-generated layout assets can be page specific; prefer exact-URL rules.', 'ndsoft-speed-doctor' )
        );
        $profiles[] = self::profile(
            'bricks',
            'Bricks',
            false !== strpos( $template, 'bricks' ) || false !== strpos( $stylesheet, 'bricks' ) || defined( 'BRICKS_VERSION' ),
            defined( 'BRICKS_VERSION' ) ? BRICKS_VERSION : '',
            __( 'Builder runtime and generated CSS stay protected by default.', 'ndsoft-speed-doctor' )
        );

        foreach ( self::optimization_plugins() as $id => $meta ) {
            $profiles[] = self::profile( $id, $meta['label'], $meta['active'], $meta['version'], $meta['note'] );
        }

        return array_values( array_filter( $profiles, static function ( $item ) { return ! empty( $item['active'] ); } ) );
    }

    public static function optimization_plugins() {
        $active = self::active_plugins();
        $known = array(
            'litespeed_cache' => array( 'file' => 'litespeed-cache/litespeed-cache.php', 'label' => 'LiteSpeed Cache', 'note' => __( 'Avoid duplicating page cache, CSS/JS minify, delay, defer, or image optimization.', 'ndsoft-speed-doctor' ) ),
            'wp_rocket'       => array( 'file' => 'wp-rocket/wp-rocket.php', 'label' => 'WP Rocket', 'note' => __( 'Avoid overlapping cache, remove-unused-CSS, delay-JS, or preload behavior.', 'ndsoft-speed-doctor' ) ),
            'autoptimize'     => array( 'file' => 'autoptimize/autoptimize.php', 'label' => 'Autoptimize', 'note' => __( 'Avoid duplicate aggregation, minification, defer, and critical-CSS behavior.', 'ndsoft-speed-doctor' ) ),
            'wp_fastest_cache'=> array( 'file' => 'wp-fastest-cache/wpFastestCache.php', 'label' => 'WP Fastest Cache', 'note' => __( 'Avoid overlapping cache/minify settings.', 'ndsoft-speed-doctor' ) ),
            'w3tc'            => array( 'file' => 'w3-total-cache/w3-total-cache.php', 'label' => 'W3 Total Cache', 'note' => __( 'Avoid overlapping page/object/browser cache and minify settings.', 'ndsoft-speed-doctor' ) ),
            'sg_optimizer'    => array( 'file' => 'sg-cachepress/sg-cachepress.php', 'label' => 'SiteGround Optimizer', 'note' => __( 'Avoid duplicate frontend/media optimization.', 'ndsoft-speed-doctor' ) ),
            'perfmatters'     => array( 'file' => 'perfmatters/perfmatters.php', 'label' => 'Perfmatters', 'note' => __( 'Avoid duplicate script manager, delay, preload, and cleanup rules.', 'ndsoft-speed-doctor' ) ),
        );
        $out = array();
        foreach ( $known as $id => $meta ) {
            $is_active = in_array( $meta['file'], $active, true );
            $out[ $id ] = array(
                'label'   => $meta['label'],
                'active'  => $is_active,
                'version' => $is_active ? self::plugin_version( $meta['file'] ) : '',
                'note'    => $meta['note'],
            );
        }
        return $out;
    }

    public static function protected_context() {
        if ( class_exists( 'WooCommerce' ) ) {
            foreach ( array( 'is_cart', 'is_checkout', 'is_account_page' ) as $fn ) {
                if ( function_exists( $fn ) && call_user_func( $fn ) ) {
                    return 'woocommerce';
                }
            }
        }
        return '';
    }

    private static function profile( $id, $label, $active, $version, $note ) {
        return array(
            'id'      => sanitize_key( $id ),
            'label'   => sanitize_text_field( $label ),
            'active'  => (bool) $active,
            'version' => sanitize_text_field( (string) $version ),
            'note'    => sanitize_text_field( $note ),
        );
    }

    private static function plugin_version( $file ) {
        if ( ! function_exists( 'get_plugin_data' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $path = WP_PLUGIN_DIR . '/' . ltrim( $file, '/' );
        if ( ! is_file( $path ) ) {
            return '';
        }
        $data = get_plugin_data( $path, false, false );
        return ! empty( $data['Version'] ) ? sanitize_text_field( $data['Version'] ) : '';
    }
}
