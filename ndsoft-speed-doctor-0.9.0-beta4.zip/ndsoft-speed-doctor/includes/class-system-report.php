<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NDSSD_System_Report {
    public static function build() {
        $environment = NDSSD_Site_Analyzer::environment();
        $theme       = wp_get_theme();
        $settings    = wp_parse_args( get_option( 'ndssd_settings', array() ), NDSSD_Plugin::defaults() );
        $scan        = get_option( 'ndssd_last_scan', array() );
        $analysis    = get_option( 'ndssd_last_local_analysis', array() );
        $assets      = get_option( NDSSD_Asset_Inspector::OPTION, array() );
        $validation  = get_option( 'ndssd_last_validation', array() );
        $fix_history = NDSSD_Fix_Engine::history();

        $report = array(
            'generated_at' => current_time( 'mysql' ),
            'plugin'       => array(
                'name'       => 'NDsoft Speed Doctor',
                'version'    => NDSSD_VERSION,
                'edition'    => NDSSD_Feature_Manager::edition(),
                'db_version' => get_option( 'ndssd_db_version', '' ),
            ),
            'site' => array(
                'home_url'  => home_url( '/' ),
                'site_url'  => site_url( '/' ),
                'https'     => is_ssl(),
                'multisite' => is_multisite(),
                'language'  => get_locale(),
                'timezone'  => wp_timezone_string(),
                'permalink' => get_option( 'permalink_structure', '' ),
            ),
            'runtime' => array(
                'wordpress'        => isset( $environment['wp_version'] ) ? $environment['wp_version'] : get_bloginfo( 'version' ),
                'php'              => isset( $environment['php_version'] ) ? $environment['php_version'] : PHP_VERSION,
                'memory_limit'     => WP_MEMORY_LIMIT,
                'max_memory_limit' => WP_MAX_MEMORY_LIMIT,
                'wp_debug'         => defined( 'WP_DEBUG' ) && WP_DEBUG,
                'object_cache'     => ! empty( $environment['object_cache'] ),
            ),
            'theme' => array(
                'name'       => $theme->get( 'Name' ),
                'version'    => $theme->get( 'Version' ),
                'stylesheet' => $theme->get_stylesheet(),
                'template'   => $theme->get_template(),
            ),
            'compatibility' => array(
                'optimization_plugins' => isset( $environment['optimization_plugins'] ) ? array_values( $environment['optimization_plugins'] ) : array(),
                'litespeed_active'      => ! empty( $environment['litespeed_active'] ),
                'profiles'              => isset( $environment['profiles'] ) ? array_values( $environment['profiles'] ) : array(),
            ),
            'keys' => array(
                'pagespeed' => NDSSD_PageSpeed_Client::api_key_source(),
            ),
            'optimization' => array(
                'cache_minutes'              => (int) $settings['cache_minutes'],
                'disable_emojis'             => ! empty( $settings['disable_emojis'] ),
                'content_image_priority'     => ! empty( $settings['content_image_priority'] ),
                'preload_featured_image'     => ! empty( $settings['preload_featured_image'] ),
                'exact_lcp_priority'         => ! empty( $settings['exact_lcp_priority'] ),
                'fix_local_image_dimensions' => ! empty( $settings['fix_local_image_dimensions'] ),
                'defer_script_handle_count'  => self::count_script_handles( $settings ),
            ),
            'assets' => array(
                'probe_url'    => ! empty( $assets['url'] ) ? esc_url_raw( $assets['url'] ) : '',
                'captured_at'  => ! empty( $assets['captured_at'] ) ? sanitize_text_field( $assets['captured_at'] ) : '',
                'style_count'  => ! empty( $assets['styles'] ) && is_array( $assets['styles'] ) ? count( $assets['styles'] ) : 0,
                'script_count' => ! empty( $assets['scripts'] ) && is_array( $assets['scripts'] ) ? count( $assets['scripts'] ) : 0,
            ),
            'latest_scan' => self::scan_summary( is_array( $scan ) ? $scan : array() ),
            'local_analysis' => array(
                'missing_dimension_count' => isset( $analysis['missing_dimension_count'] ) ? (int) $analysis['missing_dimension_count'] : 0,
                'fixable_image_count'      => isset( $analysis['fixable_image_count'] ) ? (int) $analysis['fixable_image_count'] : 0,
                'error'                    => ! empty( $analysis['error'] ) ? sanitize_text_field( $analysis['error'] ) : '',
            ),
            'validation' => array(
                'passed'         => is_array( $validation ) && ! empty( $validation['passed'] ),
                'critical_count' => is_array( $validation ) && ! empty( $validation['critical'] ) ? count( $validation['critical'] ) : 0,
                'warning_count'  => is_array( $validation ) && ! empty( $validation['warnings'] ) ? count( $validation['warnings'] ) : 0,
            ),
            'history' => array(
                'scan_entries' => count( (array) get_option( 'ndssd_scan_history', array() ) ),
                'fix_entries'  => count( is_array( $fix_history ) ? $fix_history : array() ),
            ),
        );

        return apply_filters( 'ndssd_system_report', $report );
    }

    private static function count_script_handles( array $settings ) {
        $raw = isset( $settings['defer_script_handles'] ) ? (string) $settings['defer_script_handles'] : '';
        $items = preg_split( '/[\s,]+/', $raw );
        return count( array_filter( array_map( 'trim', is_array( $items ) ? $items : array() ) ) );
    }

    private static function scan_summary( array $scan ) {
        $out = array();
        foreach ( array( 'mobile', 'desktop' ) as $strategy ) {
            if ( empty( $scan[ $strategy ] ) || ! is_array( $scan[ $strategy ] ) ) { continue; }
            $item = $scan[ $strategy ];
            $out[ $strategy ] = array(
                'performance' => isset( $item['performance'] ) ? $item['performance'] : null,
                'url'         => ! empty( $item['url'] ) ? esc_url_raw( $item['url'] ) : '',
                'fetched_at'  => ! empty( $item['fetched_at'] ) ? sanitize_text_field( $item['fetched_at'] ) : '',
                'lighthouse'  => ! empty( $item['lighthouse']['version'] ) ? sanitize_text_field( $item['lighthouse']['version'] ) : '',
            );
        }
        return $out;
    }
}
