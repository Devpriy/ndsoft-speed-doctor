<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NDSSD_Site_Analyzer {
    public static function environment() {
        $profiles = class_exists( 'NDSSD_Compatibility_Manager' ) ? NDSSD_Compatibility_Manager::profiles() : array();
        $optimization_plugins = array();
        foreach ( $profiles as $profile ) {
            if ( in_array( $profile['id'], array( 'litespeed_cache', 'wp_rocket', 'autoptimize', 'wp_fastest_cache', 'w3tc', 'sg_optimizer', 'perfmatters' ), true ) ) {
                $optimization_plugins[] = $profile['label'];
            }
        }

        return array(
            'optimization_plugins' => $optimization_plugins,
            'litespeed_active'     => in_array( 'LiteSpeed Cache', $optimization_plugins, true ),
            'object_cache'         => wp_using_ext_object_cache(),
            'wp_version'           => get_bloginfo( 'version' ),
            'php_version'          => PHP_VERSION,
            'profiles'             => $profiles,
        );
    }

    public function analyze_url( $url ) {
        $response = wp_safe_remote_get(
            esc_url_raw( $url ),
            array(
                'timeout'     => 20,
                'redirection' => 3,
                'user-agent'  => 'NDsoft-Speed-Doctor-Analyzer/' . NDSSD_VERSION,
                'headers'     => array( 'Cache-Control' => 'no-cache' ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return array( 'error' => $response->get_error_message(), 'images_missing_dimensions' => array() );
        }

        $status = (int) wp_remote_retrieve_response_code( $response );
        $html   = (string) wp_remote_retrieve_body( $response );
        if ( $status < 200 || $status >= 400 || '' === $html ) {
            return array( 'error' => sprintf( 'Frontend HTML request returned HTTP %d.', $status ), 'images_missing_dimensions' => array() );
        }

        $missing = array();
        if ( class_exists( 'WP_HTML_Tag_Processor' ) ) {
            $processor = new WP_HTML_Tag_Processor( $html );
            while ( $processor->next_tag( 'img' ) && count( $missing ) < 25 ) {
                $src = (string) $processor->get_attribute( 'src' );
                if ( '' === $src ) {
                    continue;
                }
                $width  = $processor->get_attribute( 'width' );
                $height = $processor->get_attribute( 'height' );
                if ( $width && $height ) {
                    continue;
                }
                $dims = self::local_image_dimensions( $src );
                $missing[] = array(
                    'src'              => esc_url_raw( self::absolute_url( $src, $url ) ),
                    'alt'              => sanitize_text_field( (string) $processor->get_attribute( 'alt' ) ),
                    'has_width'        => (bool) $width,
                    'has_height'       => (bool) $height,
                    'suggested_width'  => $dims ? (int) $dims[0] : 0,
                    'suggested_height' => $dims ? (int) $dims[1] : 0,
                    'fixable'          => (bool) $dims,
                );
            }
        } else {
            if ( preg_match_all( '/<img\b[^>]*>/i', $html, $matches ) ) {
                foreach ( array_slice( $matches[0], 0, 50 ) as $tag ) {
                    if ( preg_match( '/\swidth\s*=\s*["\'][^"\']+["\']/i', $tag ) && preg_match( '/\sheight\s*=\s*["\'][^"\']+["\']/i', $tag ) ) {
                        continue;
                    }
                    if ( ! preg_match( '/\ssrc\s*=\s*["\']([^"\']+)["\']/i', $tag, $src_match ) ) {
                        continue;
                    }
                    $src = html_entity_decode( $src_match[1], ENT_QUOTES, 'UTF-8' );
                    $dims = self::local_image_dimensions( $src );
                    $missing[] = array(
                        'src'              => esc_url_raw( self::absolute_url( $src, $url ) ),
                        'alt'              => '',
                        'has_width'        => (bool) preg_match( '/\swidth\s*=/i', $tag ),
                        'has_height'       => (bool) preg_match( '/\sheight\s*=/i', $tag ),
                        'suggested_width'  => $dims ? (int) $dims[0] : 0,
                        'suggested_height' => $dims ? (int) $dims[1] : 0,
                        'fixable'          => (bool) $dims,
                    );
                    if ( count( $missing ) >= 25 ) {
                        break;
                    }
                }
            }
        }

        return array(
            'error'                     => '',
            'images_missing_dimensions' => $missing,
            'missing_dimension_count'   => count( $missing ),
            'fixable_image_count'       => count( array_filter( $missing, static function ( $item ) { return ! empty( $item['fixable'] ); } ) ),
        );
    }

    public static function local_image_dimensions( $src ) {
        $path = self::url_to_local_path( $src );
        if ( ! $path || ! is_file( $path ) || ! is_readable( $path ) ) {
            return false;
        }
        $size = @getimagesize( $path );
        if ( ! is_array( $size ) || empty( $size[0] ) || empty( $size[1] ) ) {
            return false;
        }
        return array( (int) $size[0], (int) $size[1] );
    }

    public static function urls_equivalent( $a, $b ) {
        $a = self::normalize_url_for_compare( $a );
        $b = self::normalize_url_for_compare( $b );
        return $a && $b && $a === $b;
    }

    private static function normalize_url_for_compare( $url ) {
        $url = html_entity_decode( (string) $url, ENT_QUOTES, 'UTF-8' );
        if ( 0 === strpos( $url, '//' ) ) {
            $url = ( is_ssl() ? 'https:' : 'http:' ) . $url;
        } elseif ( 0 === strpos( $url, '/' ) ) {
            $url = home_url( $url );
        }
        $parts = wp_parse_url( $url );
        if ( empty( $parts['host'] ) || empty( $parts['path'] ) ) {
            return '';
        }
        return strtolower( $parts['host'] ) . rawurldecode( $parts['path'] );
    }

    private static function absolute_url( $src, $page_url ) {
        if ( preg_match( '#^https?://#i', $src ) ) {
            return $src;
        }
        if ( 0 === strpos( $src, '//' ) ) {
            return ( is_ssl() ? 'https:' : 'http:' ) . $src;
        }
        if ( 0 === strpos( $src, '/' ) ) {
            $parts = wp_parse_url( $page_url );
            if ( ! empty( $parts['scheme'] ) && ! empty( $parts['host'] ) ) {
                return $parts['scheme'] . '://' . $parts['host'] . $src;
            }
        }
        return $src;
    }

    private static function url_to_local_path( $src ) {
        $src = preg_replace( '/[?#].*$/', '', html_entity_decode( (string) $src, ENT_QUOTES, 'UTF-8' ) );
        if ( 0 === strpos( $src, '//' ) ) {
            $src = ( is_ssl() ? 'https:' : 'http:' ) . $src;
        } elseif ( 0 === strpos( $src, '/' ) ) {
            $src = home_url( $src );
        }

        $mappings = array(
            content_url( '/' )                 => trailingslashit( WP_CONTENT_DIR ),
            includes_url( '/' )                => trailingslashit( ABSPATH . WPINC ),
            get_stylesheet_directory_uri() . '/' => trailingslashit( get_stylesheet_directory() ),
            get_template_directory_uri() . '/'   => trailingslashit( get_template_directory() ),
        );

        $uploads = wp_get_upload_dir();
        if ( empty( $uploads['error'] ) && ! empty( $uploads['baseurl'] ) && ! empty( $uploads['basedir'] ) ) {
            $mappings[ trailingslashit( $uploads['baseurl'] ) ] = trailingslashit( $uploads['basedir'] );
        }

        foreach ( $mappings as $base_url => $base_dir ) {
            if ( 0 === strpos( $src, $base_url ) ) {
                $relative = ltrim( substr( $src, strlen( $base_url ) ), '/' );
                $relative = str_replace( array( '../', '..\\' ), '', rawurldecode( $relative ) );
                return wp_normalize_path( $base_dir . $relative );
            }
        }

        $home = trailingslashit( home_url( '/' ) );
        if ( 0 === strpos( $src, $home ) ) {
            $relative = ltrim( substr( $src, strlen( $home ) ), '/' );
            $relative = str_replace( array( '../', '..\\' ), '', rawurldecode( $relative ) );
            return wp_normalize_path( ABSPATH . $relative );
        }

        return false;
    }
}
