<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NDSSD_Fix_Engine {
    const HISTORY_OPTION = 'ndssd_fix_history';
    const SNAPSHOT_OPTION = 'ndssd_last_fix_snapshot';

    public static function available_fixes( array $results, array $local_analysis, array $settings ) {
        $candidate = self::lcp_candidate( $results );
        $lcp_needs_fix = self::lcp_needs_fix( $results );
        $fixable_images = isset( $local_analysis['fixable_image_count'] ) ? (int) $local_analysis['fixable_image_count'] : 0;

        return array(
            'lcp_priority' => array(
                'id'          => 'lcp_priority',
                'label'       => __( 'Exact LCP image priority', 'ndsoft-speed-doctor' ),
                'description' => __( 'Adds fetchpriority=high and loading=eager only to the exact LCP image detected by Lighthouse.', 'ndsoft-speed-doctor' ),
                'risk'        => 'low',
                'available'   => ! empty( $candidate['url'] ) && $lcp_needs_fix,
                'active'      => ! empty( $settings['exact_lcp_priority'] ) && ! empty( $settings['exact_lcp_url'] ),
                'target'      => ! empty( $candidate['url'] ) ? $candidate['url'] : '',
            ),
            'image_dimensions' => array(
                'id'          => 'image_dimensions',
                'label'       => __( 'Local image dimensions', 'ndsoft-speed-doctor' ),
                'description' => sprintf( _n( '%d local rendered image can receive missing intrinsic dimensions.', '%d local rendered images can receive missing intrinsic dimensions.', $fixable_images, 'ndsoft-speed-doctor' ), $fixable_images ),
                'risk'        => 'low',
                'available'   => $fixable_images > 0,
                'active'      => ! empty( $settings['fix_local_image_dimensions'] ),
                'target'      => $fixable_images,
            ),
            'emoji_cleanup' => array(
                'id'          => 'emoji_cleanup',
                'label'       => __( 'WordPress emoji asset cleanup', 'ndsoft-speed-doctor' ),
                'description' => __( 'Removes legacy WordPress emoji detection assets from frontend output.', 'ndsoft-speed-doctor' ),
                'risk'        => 'low',
                'available'   => true,
                'active'      => ! empty( $settings['disable_emojis'] ),
                'target'      => '',
            ),
        );
    }

    public function apply( $fix_id, $url ) {
        $settings = wp_parse_args( get_option( 'ndssd_settings', array() ), NDSSD_Plugin::defaults() );
        $results = get_option( 'ndssd_last_scan', array() );
        $analysis = get_option( 'ndssd_last_local_analysis', array() );
        $fixes = self::available_fixes( is_array( $results ) ? $results : array(), is_array( $analysis ) ? $analysis : array(), $settings );

        if ( ! isset( $fixes[ $fix_id ] ) || ! $fixes[ $fix_id ]['available'] ) {
            return new WP_Error( 'ndssd_fix_unavailable', __( 'That safe fix is not available for the current scan.', 'ndsoft-speed-doctor' ) );
        }
        if ( $fixes[ $fix_id ]['active'] ) {
            return new WP_Error( 'ndssd_fix_active', __( 'That fix is already active.', 'ndsoft-speed-doctor' ) );
        }

        $before = $settings;
        $validation_before = NDSSD_Frontend_Validator::snapshot( $url );
        if ( is_wp_error( $validation_before ) ) {
            return $validation_before;
        }
        $after = $this->apply_to_settings( $settings, $fix_id, $fixes[ $fix_id ] );
        if ( is_wp_error( $after ) ) {
            return $after;
        }

        $this->save_snapshot( $before, $fix_id, $url );
        update_option( 'ndssd_previous_settings', $before, false );
        update_option( 'ndssd_settings', $after, false );
        $purged = NDSSD_Cache_Manager::purge();
        $this->clear_psi_cache( $url );

        $health = $this->health_check( $url );
        if ( is_wp_error( $health ) ) {
            update_option( 'ndssd_settings', $before, false );
            NDSSD_Cache_Manager::purge();
            $this->clear_psi_cache( $url );
            delete_option( self::SNAPSHOT_OPTION );
            $this->log( $fix_id, 'auto-rolled-back', $url, $before, $after, $health->get_error_message(), $purged );
            return new WP_Error( 'ndssd_health_failed', sprintf( __( 'The fix was automatically rolled back because the frontend health check failed: %s', 'ndsoft-speed-doctor' ), $health->get_error_message() ) );
        }

        $validation_after = NDSSD_Frontend_Validator::snapshot( $url );
        $validation = is_wp_error( $validation_after ) ? $validation_after : NDSSD_Frontend_Validator::compare( $validation_before, $validation_after );
        if ( is_wp_error( $validation ) || empty( $validation['passed'] ) ) {
            $message = is_wp_error( $validation ) ? $validation->get_error_message() : implode( '; ', $validation['critical'] );
            update_option( 'ndssd_settings', $before, false );
            NDSSD_Cache_Manager::purge();
            $this->clear_psi_cache( $url );
            delete_option( self::SNAPSHOT_OPTION );
            $this->log( $fix_id, 'auto-rolled-back', $url, $before, $after, 'Regression guard: ' . $message, $purged );
            return new WP_Error( 'ndssd_regression_guard', sprintf( __( 'The fix was automatically rolled back because the frontend regression guard detected a structural change: %s', 'ndsoft-speed-doctor' ), $message ) );
        }
        update_option( 'ndssd_last_validation', $validation, false );
        $this->log( $fix_id, 'applied', $url, $before, $after, __( 'Frontend health and structural regression checks passed.', 'ndsoft-speed-doctor' ), $purged );
        return array( 'fix' => $fixes[ $fix_id ], 'purged' => $purged, 'health' => $health, 'validation' => $validation );
    }

    public function apply_all_safe( $url ) {
        $settings = wp_parse_args( get_option( 'ndssd_settings', array() ), NDSSD_Plugin::defaults() );
        $results = get_option( 'ndssd_last_scan', array() );
        $analysis = get_option( 'ndssd_last_local_analysis', array() );
        $fixes = self::available_fixes( is_array( $results ) ? $results : array(), is_array( $analysis ) ? $analysis : array(), $settings );
        $eligible = array();
        foreach ( $fixes as $fix_id => $fix ) {
            if ( $fix['available'] && ! $fix['active'] ) {
                $eligible[] = $fix_id;
            }
        }

        if ( ! $eligible ) {
            return new WP_Error( 'ndssd_no_safe_fixes', __( 'No additional safe fixes are available from the latest scan.', 'ndsoft-speed-doctor' ) );
        }

        $before = $settings;
        $validation_before = NDSSD_Frontend_Validator::snapshot( $url );
        if ( is_wp_error( $validation_before ) ) {
            return $validation_before;
        }
        $after = $settings;
        foreach ( $eligible as $fix_id ) {
            $after = $this->apply_to_settings( $after, $fix_id, $fixes[ $fix_id ] );
            if ( is_wp_error( $after ) ) {
                return $after;
            }
        }

        $this->save_snapshot( $before, 'safe_bundle', $url );
        update_option( 'ndssd_previous_settings', $before, false );
        update_option( 'ndssd_settings', $after, false );
        $purged = NDSSD_Cache_Manager::purge();
        $this->clear_psi_cache( $url );
        $health = $this->health_check( $url );

        if ( is_wp_error( $health ) ) {
            update_option( 'ndssd_settings', $before, false );
            NDSSD_Cache_Manager::purge();
            $this->clear_psi_cache( $url );
            delete_option( self::SNAPSHOT_OPTION );
            $this->log( 'safe_bundle', 'auto-rolled-back', $url, $before, $after, $health->get_error_message(), $purged, $eligible );
            return new WP_Error( 'ndssd_health_failed', sprintf( __( 'Safe Fix All was automatically rolled back because the frontend health check failed: %s', 'ndsoft-speed-doctor' ), $health->get_error_message() ) );
        }

        $validation_after = NDSSD_Frontend_Validator::snapshot( $url );
        $validation = is_wp_error( $validation_after ) ? $validation_after : NDSSD_Frontend_Validator::compare( $validation_before, $validation_after );
        if ( is_wp_error( $validation ) || empty( $validation['passed'] ) ) {
            $message = is_wp_error( $validation ) ? $validation->get_error_message() : implode( '; ', $validation['critical'] );
            update_option( 'ndssd_settings', $before, false );
            NDSSD_Cache_Manager::purge();
            $this->clear_psi_cache( $url );
            delete_option( self::SNAPSHOT_OPTION );
            $this->log( 'safe_bundle', 'auto-rolled-back', $url, $before, $after, 'Regression guard: ' . $message, $purged, $eligible );
            return new WP_Error( 'ndssd_regression_guard', sprintf( __( 'Safe Fix All was rolled back because the frontend regression guard detected a structural change: %s', 'ndsoft-speed-doctor' ), $message ) );
        }
        update_option( 'ndssd_last_validation', $validation, false );
        $this->log( 'safe_bundle', 'applied', $url, $before, $after, __( 'Frontend health and structural regression checks passed.', 'ndsoft-speed-doctor' ), $purged, $eligible );
        return array( 'fix_ids' => $eligible, 'purged' => $purged, 'health' => $health, 'validation' => $validation );
    }

    public function rollback_last() {
        $snapshot = get_option( self::SNAPSHOT_OPTION, array() );
        if ( ! is_array( $snapshot ) || empty( $snapshot['settings'] ) || ! is_array( $snapshot['settings'] ) ) {
            return new WP_Error( 'ndssd_no_fix_snapshot', __( 'No one-click fix snapshot is available to roll back.', 'ndsoft-speed-doctor' ) );
        }

        $current = wp_parse_args( get_option( 'ndssd_settings', array() ), NDSSD_Plugin::defaults() );
        update_option( 'ndssd_previous_settings', $current, false );
        update_option( 'ndssd_settings', wp_parse_args( $snapshot['settings'], NDSSD_Plugin::defaults() ), false );
        $purged = NDSSD_Cache_Manager::purge();
        if ( ! empty( $snapshot['url'] ) ) {
            $this->clear_psi_cache( $snapshot['url'] );
        }
        $this->log( isset( $snapshot['fix_id'] ) ? $snapshot['fix_id'] : 'unknown', 'rolled-back', isset( $snapshot['url'] ) ? $snapshot['url'] : '', $current, $snapshot['settings'], __( 'Manual one-click rollback completed.', 'ndsoft-speed-doctor' ), $purged );
        delete_option( self::SNAPSHOT_OPTION );
        return $purged;
    }

    public static function history() {
        $history = get_option( self::HISTORY_OPTION, array() );
        return is_array( $history ) ? $history : array();
    }

    public static function has_snapshot() {
        $snapshot = get_option( self::SNAPSHOT_OPTION, array() );
        return is_array( $snapshot ) && ! empty( $snapshot['settings'] );
    }

    public static function mark_latest_verified( array $before_scan, array $after_scan ) {
        $history = self::history();
        if ( ! $history ) {
            return;
        }
        for ( $i = count( $history ) - 1; $i >= 0; $i-- ) {
            if ( isset( $history[ $i ]['status'] ) && 'applied' === $history[ $i ]['status'] ) {
                $history[ $i ]['status'] = 'verified';
                $history[ $i ]['verified_at'] = current_time( 'mysql' );
                $history[ $i ]['before_score'] = self::score_snapshot( $before_scan );
                $history[ $i ]['after_score'] = self::score_snapshot( $after_scan );
                break;
            }
        }
        update_option( self::HISTORY_OPTION, $history, false );
    }

    private function apply_to_settings( array $settings, $fix_id, array $fix ) {
        switch ( $fix_id ) {
            case 'lcp_priority':
                if ( empty( $fix['target'] ) ) {
                    return new WP_Error( 'ndssd_lcp_target_missing', __( 'The exact LCP image URL is unavailable.', 'ndsoft-speed-doctor' ) );
                }
                $settings['exact_lcp_priority'] = 1;
                $settings['exact_lcp_url'] = esc_url_raw( $fix['target'] );
                break;
            case 'image_dimensions':
                $settings['fix_local_image_dimensions'] = 1;
                break;
            case 'emoji_cleanup':
                $settings['disable_emojis'] = 1;
                break;
            default:
                return new WP_Error( 'ndssd_unknown_fix', __( 'Unknown safe fix.', 'ndsoft-speed-doctor' ) );
        }
        return $settings;
    }

    private function save_snapshot( array $settings, $fix_id, $url ) {
        update_option(
            self::SNAPSHOT_OPTION,
            array(
                'created_at' => current_time( 'mysql' ),
                'fix_id'     => sanitize_key( $fix_id ),
                'url'        => esc_url_raw( $url ),
                'settings'   => $settings,
            ),
            false
        );
    }

    private function clear_psi_cache( $url ) {
        if ( class_exists( 'NDSSD_PageSpeed_Client' ) ) {
            $client = new NDSSD_PageSpeed_Client();
            $client->clear_cache( $url );
        }
    }

    private function health_check( $url ) {
        $response = wp_safe_remote_get(
            esc_url_raw( $url ),
            array(
                'timeout'     => 20,
                'redirection' => 3,
                'headers'     => array( 'Cache-Control' => 'no-cache' ),
                'user-agent'  => 'NDsoft-Speed-Doctor-Health/' . NDSSD_VERSION,
            )
        );
        if ( is_wp_error( $response ) ) {
            return $response;
        }
        $status = (int) wp_remote_retrieve_response_code( $response );
        $body = (string) wp_remote_retrieve_body( $response );
        if ( $status < 200 || $status >= 400 ) {
            return new WP_Error( 'ndssd_http_health', sprintf( __( 'HTTP %d returned.', 'ndsoft-speed-doctor' ), $status ) );
        }
        if ( strlen( trim( $body ) ) < 100 ) {
            return new WP_Error( 'ndssd_empty_health', __( 'Frontend returned unexpectedly little HTML.', 'ndsoft-speed-doctor' ) );
        }
        return array( 'status' => $status, 'bytes' => strlen( $body ) );
    }

    private function log( $fix_id, $status, $url, array $before, array $after, $message, array $purged = array(), array $children = array() ) {
        $history = self::history();
        $history[] = array(
            'created_at' => current_time( 'mysql' ),
            'fix_id'     => sanitize_key( $fix_id ),
            'status'     => sanitize_key( $status ),
            'url'        => esc_url_raw( $url ),
            'message'    => sanitize_text_field( $message ),
            'purged'     => array_map( 'sanitize_text_field', $purged ),
            'children'   => array_map( 'sanitize_key', $children ),
            'before'     => self::settings_state( $before ),
            'after'      => self::settings_state( $after ),
        );
        if ( count( $history ) > 20 ) {
            $history = array_slice( $history, -20 );
        }
        update_option( self::HISTORY_OPTION, $history, false );
    }

    private static function settings_state( array $settings ) {
        return array(
            'disable_emojis'             => ! empty( $settings['disable_emojis'] ),
            'exact_lcp_priority'         => ! empty( $settings['exact_lcp_priority'] ),
            'exact_lcp_url'              => ! empty( $settings['exact_lcp_url'] ) ? esc_url_raw( $settings['exact_lcp_url'] ) : '',
            'fix_local_image_dimensions' => ! empty( $settings['fix_local_image_dimensions'] ),
        );
    }

    private static function lcp_needs_fix( array $results ) {
        foreach ( array( 'mobile', 'desktop' ) as $strategy ) {
            if ( empty( $results[ $strategy ]['diagnostics']['lcp_discovery'] ) ) {
                continue;
            }
            $diag = $results[ $strategy ]['diagnostics']['lcp_discovery'];
            if ( ! array_key_exists( 'score', $diag ) || null === $diag['score'] || (float) $diag['score'] < 0.9 ) {
                return true;
            }
        }
        return false;
    }

    private static function lcp_candidate( array $results ) {
        foreach ( array( 'mobile', 'desktop' ) as $strategy ) {
            if ( ! empty( $results[ $strategy ]['lcp_candidate']['url'] ) ) {
                return $results[ $strategy ]['lcp_candidate'];
            }
        }
        return array();
    }

    private static function score_snapshot( array $scan ) {
        return array(
            'mobile'  => isset( $scan['mobile']['performance'] ) ? $scan['mobile']['performance'] : null,
            'desktop' => isset( $scan['desktop']['performance'] ) ? $scan['desktop']['performance'] : null,
        );
    }
}
