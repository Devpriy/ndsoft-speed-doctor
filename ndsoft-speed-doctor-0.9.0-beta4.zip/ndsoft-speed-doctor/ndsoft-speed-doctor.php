<?php
/**
 * Plugin Name: NDsoft Speed Doctor
 * Plugin URI: https://ndsoftdesign.com/ndsoft-speed-doctor/
 * Description: PageSpeed Insights and Core Web Vitals diagnostics with safe, opt-in WordPress performance fixes.
 * Version: 0.9.0-beta4
 * Author: NDsoftDesign
 * Author URI: https://ndsoftdesign.com/
 * Text Domain: ndsoft-speed-doctor
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'NDSSD_VERSION', '0.9.0-beta4' );
define( 'NDSSD_FILE', __FILE__ );
define( 'NDSSD_DIR', plugin_dir_path( __FILE__ ) );
define( 'NDSSD_URL', plugin_dir_url( __FILE__ ) );

require_once NDSSD_DIR . 'includes/class-plugin.php';

register_activation_hook( __FILE__, array( 'NDSSD_Plugin', 'activate' ) );

NDSSD_Plugin::instance();

