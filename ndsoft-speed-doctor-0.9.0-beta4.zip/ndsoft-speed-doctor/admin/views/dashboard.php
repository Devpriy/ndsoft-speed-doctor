<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function ndssd_score_class( $score ) {
    if ( null === $score ) {
        return 'ndssd-neutral';
    }
    if ( $score >= 90 ) {
        return 'ndssd-good';
    }
    if ( $score >= 50 ) {
        return 'ndssd-needs';
    }
    return 'ndssd-poor';
}

function ndssd_field_value( $label, $metric ) {
    if ( ! isset( $metric['percentile'] ) || null === $metric['percentile'] ) {
        return '—';
    }
    $value = (float) $metric['percentile'];
    if ( 'CLS' === $label ) {
        return number_format_i18n( $value / 100, 2 );
    }
    return number_format_i18n( $value, 0 ) . ' ms';
}

function ndssd_diag_state( $diag ) {
    if ( ! is_array( $diag ) || ! array_key_exists( 'score', $diag ) || null === $diag['score'] ) {
        return 'info';
    }
    if ( $diag['score'] >= 0.9 ) {
        return 'pass';
    }
    if ( $diag['score'] >= 0.5 ) {
        return 'warn';
    }
    return 'fail';
}

function ndssd_format_bytes( $bytes ) {
    $bytes = (int) $bytes;
    if ( $bytes <= 0 ) {
        return '';
    }
    return size_format( $bytes, 1 );
}

function ndssd_metric_numeric( $result, $id ) {
    return isset( $result['lab'][ $id ]['numeric_value'] ) && null !== $result['lab'][ $id ]['numeric_value'] ? (float) $result['lab'][ $id ]['numeric_value'] : null;
}

function ndssd_delta_label( $current, $previous, $higher_is_better = false, $suffix = '' ) {
    if ( null === $current || null === $previous ) {
        return '<span class="ndssd-delta neutral">—</span>';
    }
    $delta = $current - $previous;
    if ( abs( $delta ) < 0.001 ) {
        return '<span class="ndssd-delta neutral">No change</span>';
    }
    $improved = $higher_is_better ? $delta > 0 : $delta < 0;
    $arrow = $delta > 0 ? '↑' : '↓';
    $value = abs( $delta );
    $formatted = $suffix ? number_format_i18n( $value, 0 ) . $suffix : number_format_i18n( $value, 2 );
    return '<span class="ndssd-delta ' . ( $improved ? 'good' : 'bad' ) . '">' . esc_html( $arrow . ' ' . $formatted ) . '</span>';
}

$api_configured = '' !== NDSSD_PageSpeed_Client::api_key();
$pagespeed_key_source = NDSSD_PageSpeed_Client::api_key_source();
$latest_url = ! empty( $results['mobile']['url'] ) ? $results['mobile']['url'] : ( ! empty( $results['desktop']['url'] ) ? $results['desktop']['url'] : home_url( '/' ) );
$lcp_candidate = array();
foreach ( array( 'mobile', 'desktop' ) as $candidate_strategy ) {
    if ( ! empty( $results[ $candidate_strategy ]['lcp_candidate'] ) ) {
        $lcp_candidate = $results[ $candidate_strategy ]['lcp_candidate'];
        if ( ! empty( $lcp_candidate['url'] ) ) {
            break;
        }
    }
}
?>
<div class="wrap ndssd-wrap">
    <div class="ndssd-header">
        <div>
            <h1><?php esc_html_e( 'NDsoft Speed Doctor', 'ndsoft-speed-doctor' ); ?> <span class="ndssd-version">v<?php echo esc_html( NDSSD_VERSION ); ?></span></h1>
            <p><?php esc_html_e( 'Diagnose PageSpeed and Core Web Vitals, apply targeted fixes, and verify the result.', 'ndsoft-speed-doctor' ); ?></p>
        </div>
        <div class="ndssd-header-badges">
            <?php if ( 'free' === $edition ) : ?>
                <a class="button button-primary ndssd-pro-cta" href="<?php echo esc_url( $upgrade_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Get Pro', 'ndsoft-speed-doctor' ); ?></a>
            <?php endif; ?>
            <span class="ndssd-edition-badge <?php echo esc_attr( $edition ); ?>"><?php echo esc_html( strtoupper( $edition ) ); ?></span>
            <?php if ( 'pro' === $edition && class_exists( 'NDSSD_Integrations' ) && NDSSD_Integrations::native_ready() ) : ?><span class="ndssd-status ok"><?php esc_html_e( 'Auto Fix ready', 'ndsoft-speed-doctor' ); ?></span><?php endif; ?>
            <span class="ndssd-badge">Safe-by-default</span>
            <span class="ndssd-status <?php echo $api_configured ? 'ok' : 'warn'; ?>"><?php echo $api_configured ? esc_html__( 'API key configured', 'ndsoft-speed-doctor' ) : esc_html__( 'API key missing', 'ndsoft-speed-doctor' ); ?></span>
        </div>
    </div>

    <?php if ( $message ) : ?>
        <div class="notice notice-<?php echo 'error' === $notice ? 'error' : ( 'warning' === $notice ? 'warning' : 'success' ); ?> is-dismissible"><p><?php echo esc_html( $message ); ?></p></div>
    <?php endif; ?>

    <?php if ( ! empty( $environment['optimization_plugins'] ) ) : ?>
        <div class="ndssd-compat-note">
            <strong><?php esc_html_e( 'Compatibility detected:', 'ndsoft-speed-doctor' ); ?></strong>
            <?php echo esc_html( implode( ', ', $environment['optimization_plugins'] ) ); ?>.
            <?php esc_html_e( 'Avoid duplicating CSS/JS delay, defer, minify, or cache features across multiple plugins.', 'ndsoft-speed-doctor' ); ?>
        </div>
    <?php endif; ?>

    <div class="ndssd-grid ndssd-grid-2">
        <section class="ndssd-card">
            <h2><?php esc_html_e( '1. Run PageSpeed Scan', 'ndsoft-speed-doctor' ); ?></h2>
            <p><?php esc_html_e( 'Scans mobile and desktop. Results are cached locally to reduce PageSpeed API quota usage.', 'ndsoft-speed-doctor' ); ?></p>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="ndssd_run_scan">
                <?php wp_nonce_field( 'ndssd_scan' ); ?>
                <div class="ndssd-form-row">
                    <label for="ndssd-scan-url"><strong><?php esc_html_e( 'Page URL', 'ndsoft-speed-doctor' ); ?></strong></label>
                    <input id="ndssd-scan-url" class="regular-text code" type="url" name="scan_url" value="<?php echo esc_attr( $latest_url ); ?>" required>
                </div>
                <label class="ndssd-check"><input type="checkbox" name="force_refresh" value="1"> <?php esc_html_e( 'Force fresh Google API scan (uses quota)', 'ndsoft-speed-doctor' ); ?></label>
                <div class="ndssd-actions">
                    <?php submit_button( __( 'Scan Mobile + Desktop', 'ndsoft-speed-doctor' ), 'primary', 'submit', false ); ?>
                </div>
            </form>
        </section>

        <section class="ndssd-card">
            <h2><?php esc_html_e( 'System status', 'ndsoft-speed-doctor' ); ?></h2>
            <div class="ndssd-status-grid">
                <div><span><?php esc_html_e( 'PageSpeed API', 'ndsoft-speed-doctor' ); ?></span><strong><?php echo $api_configured ? esc_html__( 'Configured', 'ndsoft-speed-doctor' ) : esc_html__( 'Not configured', 'ndsoft-speed-doctor' ); ?><?php if ( 'constant' === $pagespeed_key_source ) : ?> · wp-config.php<?php endif; ?></strong></div>
                <div><span><?php esc_html_e( 'Scan cache', 'ndsoft-speed-doctor' ); ?></span><strong><?php echo esc_html( (int) $settings['cache_minutes'] ); ?> min</strong></div>
                <div><span><?php esc_html_e( 'WordPress', 'ndsoft-speed-doctor' ); ?></span><strong><?php echo esc_html( $environment['wp_version'] ); ?></strong></div>
                <div><span><?php esc_html_e( 'PHP', 'ndsoft-speed-doctor' ); ?></span><strong><?php echo esc_html( $environment['php_version'] ); ?></strong></div>
                <div><span><?php esc_html_e( 'Edition', 'ndsoft-speed-doctor' ); ?></span><strong><?php echo esc_html( ucfirst( $edition ) ); ?></strong></div>
                <div><span><?php esc_html_e( 'Safe Fix snapshot', 'ndsoft-speed-doctor' ); ?></span><strong><?php echo $has_fix_snapshot ? esc_html__( 'Available', 'ndsoft-speed-doctor' ) : esc_html__( 'None', 'ndsoft-speed-doctor' ); ?></strong></div>
            </div>
            <div class="ndssd-actions">
                <?php if ( $api_configured ) : ?>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="ndssd_test_api"><?php wp_nonce_field( 'ndssd_test_api' ); ?>
                        <?php submit_button( __( 'Test API Connection', 'ndsoft-speed-doctor' ), 'secondary', 'submit', false ); ?>
                    </form>
                <?php endif; ?>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <input type="hidden" name="action" value="ndssd_clear_scan_cache"><input type="hidden" name="scan_url" value="<?php echo esc_attr( $latest_url ); ?>"><?php wp_nonce_field( 'ndssd_clear_scan_cache' ); ?>
                    <?php submit_button( __( 'Clear Scan Cache', 'ndsoft-speed-doctor' ), 'secondary', 'submit', false ); ?>
                </form>
            </div>
        </section>
    </div>

    <?php if ( ! empty( $results ) ) : ?>
        <h2 class="ndssd-section-title"><?php esc_html_e( 'Latest Scan', 'ndsoft-speed-doctor' ); ?></h2>
        <div class="ndssd-grid ndssd-grid-2">
            <?php foreach ( array( 'mobile', 'desktop' ) as $strategy ) : ?>
                <?php if ( empty( $results[ $strategy ] ) ) { continue; } $result = $results[ $strategy ]; ?>
                <section class="ndssd-card">
                    <div class="ndssd-card-heading">
                        <div>
                            <h2><?php echo esc_html( ucfirst( $strategy ) ); ?></h2>
                            <span class="ndssd-mini-status"><?php echo isset( $result['cache_status'] ) && 'hit' === $result['cache_status'] ? esc_html__( 'Cached', 'ndsoft-speed-doctor' ) : esc_html__( 'Fresh', 'ndsoft-speed-doctor' ); ?></span>
                        </div>
                        <div class="ndssd-score <?php echo esc_attr( ndssd_score_class( $result['performance'] ) ); ?>"><?php echo null === $result['performance'] ? '—' : esc_html( $result['performance'] ); ?></div>
                    </div>
                    <p class="description"><?php echo esc_html( $result['url'] ); ?> · <?php echo esc_html( $result['fetched_at'] ); ?><?php if ( ! empty( $result['lighthouse']['version'] ) ) : ?> · Lighthouse <?php echo esc_html( $result['lighthouse']['version'] ); ?><?php endif; ?></p>

                    <?php if ( ! empty( $result['lab'] ) ) : ?>
                        <h3><?php esc_html_e( 'Lighthouse lab metrics', 'ndsoft-speed-doctor' ); ?></h3>
                        <div class="ndssd-metrics">
                            <?php foreach ( $result['lab'] as $metric ) : ?>
                                <div><span><?php echo esc_html( $metric['label'] ); ?></span><strong><?php echo esc_html( $metric['display_value'] ); ?></strong></div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <?php $field_metrics = ! empty( $result['field'] ) ? $result['field'] : ( ! empty( $result['origin_field'] ) ? $result['origin_field'] : array() ); ?>
                    <h3><?php esc_html_e( 'Real-user field data', 'ndsoft-speed-doctor' ); ?></h3>
                    <?php if ( $field_metrics ) : ?>
                        <div class="ndssd-metrics">
                            <?php foreach ( $field_metrics as $label => $metric ) : ?>
                                <div><span><?php echo esc_html( $label ); ?></span><strong><?php echo esc_html( ndssd_field_value( $label, $metric ) ); ?></strong><small><?php echo esc_html( strtoupper( str_replace( '_', ' ', $metric['category'] ) ) ); ?></small></div>
                            <?php endforeach; ?>
                        </div>
                    <?php else : ?>
                        <p class="description"><?php esc_html_e( 'No CrUX field data was returned for this URL/origin. Lab data can still be used for immediate testing.', 'ndsoft-speed-doctor' ); ?></p>
                    <?php endif; ?>
                </section>
            <?php endforeach; ?>
        </div>

        <h2 class="ndssd-section-title"><?php esc_html_e( 'Compatibility & Frontend Asset Map', 'ndsoft-speed-doctor' ); ?></h2>
        <div class="ndssd-grid ndssd-grid-2">
            <section class="ndssd-card">
                <div class="ndssd-card-heading">
                    <div>
                        <h2><?php esc_html_e( 'Compatibility profiles', 'ndsoft-speed-doctor' ); ?></h2>
                        <p class="description"><?php esc_html_e( 'Detected builders, commerce layers, and optimization plugins change which fixes are considered safe.', 'ndsoft-speed-doctor' ); ?></p>
                    </div>
                    <span class="ndssd-badge"><?php echo esc_html( count( $compatibility_profiles ) ); ?> detected</span>
                </div>
                <?php if ( $compatibility_profiles ) : ?>
                    <div class="ndssd-resource-list">
                        <?php foreach ( $compatibility_profiles as $profile ) : ?>
                            <div class="ndssd-resource">
                                <strong><?php echo esc_html( $profile['label'] ); ?><?php if ( ! empty( $profile['version'] ) ) : ?> <small>v<?php echo esc_html( $profile['version'] ); ?></small><?php endif; ?></strong>
                                <span><?php echo esc_html( $profile['note'] ); ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else : ?>
                    <p class="description"><?php esc_html_e( 'No special compatibility profile is currently required.', 'ndsoft-speed-doctor' ); ?></p>
                <?php endif; ?>
            </section>

            <section class="ndssd-card">
                <div class="ndssd-card-heading">
                    <div>
                        <h2><?php esc_html_e( 'Frontend asset probe', 'ndsoft-speed-doctor' ); ?></h2>
                        <p class="description"><?php esc_html_e( 'Capture the actual WordPress style/script handles rendered on the scanned URL so PageSpeed resource URLs can be mapped back to WordPress handles.', 'ndsoft-speed-doctor' ); ?></p>
                    </div>
                    <?php if ( ! empty( $asset_inventory['captured_at'] ) ) : ?><span class="ndssd-mini-status"><?php echo esc_html( $asset_inventory['captured_at'] ); ?></span><?php endif; ?>
                </div>
                <div class="ndssd-status-grid">
                    <div><span><?php esc_html_e( 'Styles', 'ndsoft-speed-doctor' ); ?></span><strong><?php echo esc_html( ! empty( $asset_inventory['styles'] ) ? count( $asset_inventory['styles'] ) : 0 ); ?></strong></div>
                    <div><span><?php esc_html_e( 'Scripts', 'ndsoft-speed-doctor' ); ?></span><strong><?php echo esc_html( ! empty( $asset_inventory['scripts'] ) ? count( $asset_inventory['scripts'] ) : 0 ); ?></strong></div>
                    <div><span><?php esc_html_e( 'Target', 'ndsoft-speed-doctor' ); ?></span><strong><?php echo esc_html( wp_parse_url( $latest_url, PHP_URL_PATH ) ?: '/' ); ?></strong></div>
                </div>
                <?php if ( $asset_probe_error ) : ?>
                    <div class="ndssd-warning-box"><strong><?php esc_html_e( 'Automatic asset probe:', 'ndsoft-speed-doctor' ); ?></strong> <?php echo esc_html( $asset_probe_error ); ?> <?php esc_html_e( 'Use the manual probe button after purging page cache.', 'ndsoft-speed-doctor' ); ?></div>
                <?php endif; ?>
                <div class="ndssd-actions">
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="ndssd_probe_assets">
                        <?php wp_nonce_field( 'ndssd_probe_assets' ); ?>
                        <?php submit_button( __( 'Probe Frontend Assets', 'ndsoft-speed-doctor' ), 'secondary', 'submit', false ); ?>
                    </form>

                </div>
                <?php if ( ! empty( $asset_inventory['styles'] ) || ! empty( $asset_inventory['scripts'] ) ) : ?>
                    <details class="ndssd-inline-details">
                        <summary><?php esc_html_e( 'Show captured handles', 'ndsoft-speed-doctor' ); ?></summary>
                        <div class="ndssd-resource-list">
                            <?php foreach ( array_slice( array_merge( (array) ( $asset_inventory['styles'] ?? array() ), (array) ( $asset_inventory['scripts'] ?? array() ) ), 0, 40 ) as $asset ) : ?>
                                <div class="ndssd-resource"><strong><?php echo esc_html( strtoupper( substr( $asset['type'], 0, 1 ) ) . ' · ' . $asset['handle'] ); ?></strong><code><?php echo esc_html( $asset['src'] ); ?></code><small><?php echo esc_html( $asset['owner'] . ' · ' . $asset['state'] ); ?></small></div>
                            <?php endforeach; ?>
                        </div>
                    </details>
                <?php endif; ?>
            </section>
        </div>

        <h2 class="ndssd-section-title"><?php esc_html_e( 'Issue Diagnostics', 'ndsoft-speed-doctor' ); ?></h2>
        <div class="ndssd-grid ndssd-grid-2">
            <?php foreach ( array( 'mobile', 'desktop' ) as $strategy ) : ?>
                <?php if ( empty( $results[ $strategy ] ) ) { continue; } $result = $results[ $strategy ]; ?>
                <section class="ndssd-card">
                    <h2><?php echo esc_html( ucfirst( $strategy ) ); ?> <?php esc_html_e( 'diagnostics', 'ndsoft-speed-doctor' ); ?></h2>
                    <?php if ( ! empty( $result['diagnostics'] ) ) : ?>
                        <div class="ndssd-diagnostics">
                            <?php foreach ( $result['diagnostics'] as $key => $diag ) : ?>
                                <details class="ndssd-diagnostic <?php echo esc_attr( ndssd_diag_state( $diag ) ); ?>" <?php echo in_array( $key, array( 'lcp_discovery', 'render_blocking', 'unsized_images' ), true ) ? 'open' : ''; ?>>
                                    <summary><span><?php echo esc_html( $diag['title'] ); ?></span><?php if ( ! empty( $diag['display_value'] ) ) : ?><em><?php echo esc_html( $diag['display_value'] ); ?></em><?php endif; ?></summary>
                                    <?php if ( ! empty( $diag['description'] ) ) : ?><p><?php echo esc_html( $diag['description'] ); ?></p><?php endif; ?>
                                    <?php if ( ! empty( $diag['items'] ) ) : ?>
                                        <div class="ndssd-resource-list">
                                            <?php foreach ( array_slice( $diag['items'], 0, 8 ) as $item ) : ?>
                                                <div class="ndssd-resource">
                                                    <?php if ( ! empty( $item['url'] ) ) : ?><code><?php echo esc_html( $item['url'] ); ?></code><?php endif; ?>
                                                    <?php if ( ! empty( $item['selector'] ) ) : ?><code><?php echo esc_html( $item['selector'] ); ?></code><?php endif; ?>
                                                    <?php if ( ! empty( $item['snippet'] ) ) : ?><span><?php echo esc_html( wp_html_excerpt( $item['snippet'], 180, '…' ) ); ?></span><?php endif; ?>
                                                    <small><?php if ( ! empty( $item['wasted_ms'] ) ) { echo esc_html( round( $item['wasted_ms'] ) . ' ms potential saving ' ); } ?><?php if ( ! empty( $item['wasted_bytes'] ) ) { echo esc_html( ndssd_format_bytes( $item['wasted_bytes'] ) . ' potential saving' ); } ?></small>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </details>
                            <?php endforeach; ?>
                        </div>
                    <?php elseif ( ! empty( $result['recommendations'] ) ) : ?>
                        <div class="ndssd-diagnostics">
                            <?php foreach ( $result['recommendations'] as $item ) : ?>
                                <div class="ndssd-diagnostic info"><strong><?php echo esc_html( $item['title'] ); ?></strong><?php if ( $item['display_value'] ) : ?> <span><?php echo esc_html( $item['display_value'] ); ?></span><?php endif; ?></div>
                            <?php endforeach; ?>
                        </div>
                    <?php else : ?>
                        <p class="description"><?php esc_html_e( 'No significant diagnostics returned.', 'ndsoft-speed-doctor' ); ?></p>
                    <?php endif; ?>
                </section>
            <?php endforeach; ?>
        </div>

        <h2 class="ndssd-section-title"><?php esc_html_e( 'Optimization Journey', 'ndsoft-speed-doctor' ); ?></h2>
        <section class="ndssd-card ndssd-journey-card">
            <div class="ndssd-journey-head">
                <div>
                    <h2><?php esc_html_e( 'Free first. Advanced when the site needs it.', 'ndsoft-speed-doctor' ); ?></h2>
                    <p><?php esc_html_e( 'Free fixes are real optimizations, not a limited demo. Pro is for deeper dependency-aware work, automation, AI/MCP analysis, and harder legacy sites.', 'ndsoft-speed-doctor' ); ?></p>
                </div>
                <span class="ndssd-edition-badge <?php echo esc_attr( $edition ); ?>"><?php echo esc_html( strtoupper( $edition ) ); ?></span>
            </div>

            <div class="ndssd-journey-grid">
                <div class="ndssd-journey-score">
                    <span><?php esc_html_e( 'Current mobile', 'ndsoft-speed-doctor' ); ?></span>
                    <strong><?php echo null === $optimization_summary['mobile_score'] ? '—' : esc_html( $optimization_summary['mobile_score'] ); ?></strong>
                    <small><?php esc_html_e( 'Measured PageSpeed score', 'ndsoft-speed-doctor' ); ?></small>
                </div>
                <div class="ndssd-journey-score">
                    <span><?php esc_html_e( 'Current desktop', 'ndsoft-speed-doctor' ); ?></span>
                    <strong><?php echo null === $optimization_summary['desktop_score'] ? '—' : esc_html( $optimization_summary['desktop_score'] ); ?></strong>
                    <small><?php esc_html_e( 'Measured PageSpeed score', 'ndsoft-speed-doctor' ); ?></small>
                </div>
                <div class="ndssd-journey-score free">
                    <span><?php esc_html_e( 'Free fixes remaining', 'ndsoft-speed-doctor' ); ?></span>
                    <strong><?php echo esc_html( (int) $optimization_summary['free_remaining'] ); ?></strong>
                    <small><?php echo esc_html( sprintf( __( '%d Free fix(es) already active', 'ndsoft-speed-doctor' ), (int) $optimization_summary['free_active'] ) ); ?></small>
                </div>
                <div class="ndssd-journey-score pro">
                    <span><?php esc_html_e( 'Advanced opportunities', 'ndsoft-speed-doctor' ); ?></span>
                    <strong><?php echo esc_html( count( $advanced_opportunities ) ); ?></strong>
                    <small><?php esc_html_e( 'Potential Pro analysis areas', 'ndsoft-speed-doctor' ); ?></small>
                </div>
            </div>

            <div class="ndssd-trust-note">
                <strong><?php esc_html_e( 'No artificial score cap:', 'ndsoft-speed-doctor' ); ?></strong>
                <?php esc_html_e( 'Free can reach excellent scores when the site allows it. Pro unlocks deeper optimization; it does not guarantee a specific PageSpeed score.', 'ndsoft-speed-doctor' ); ?>
            </div>

            <?php if ( $advanced_opportunities ) : ?>
                <div class="ndssd-advanced-preview">
                    <div class="ndssd-advanced-preview-head">
                        <div>
                            <h3><?php esc_html_e( 'Remaining advanced opportunities', 'ndsoft-speed-doctor' ); ?></h3>
                            <p><?php esc_html_e( 'These are detected from the latest scan and are intentionally not auto-rewritten by the Free engine.', 'ndsoft-speed-doctor' ); ?></p>
                        </div>
                        <?php if ( 'pro' !== $edition ) : ?>
                            <a class="button button-primary" href="<?php echo esc_url( $upgrade_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'View Pro', 'ndsoft-speed-doctor' ); ?></a>
                        <?php endif; ?>
                    </div>
                    <div class="ndssd-advanced-list">
                        <?php foreach ( array_slice( $advanced_opportunities, 0, 6 ) as $opportunity ) : ?>
                            <div>
                                <span class="dashicons dashicons-lock"></span>
                                <strong><?php echo esc_html( $opportunity['label'] ); ?></strong>
                                <small><?php echo esc_html( ucfirst( implode( ' + ', $opportunity['strategies'] ) ) ); ?><?php if ( ! empty( $opportunity['display'] ) ) : ?> · <?php echo esc_html( $opportunity['display'] ); ?><?php endif; ?></small>
                                <p><?php echo esc_html( $opportunity['description'] ); ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php elseif ( ! empty( $results ) ) : ?>
                <div class="ndssd-success-panel">
                    <strong>✓ <?php esc_html_e( 'No significant advanced opportunities are currently detected.', 'ndsoft-speed-doctor' ); ?></strong>
                    <p><?php esc_html_e( 'This site may already be highly optimized. Pro is most valuable when deeper bottlenecks, multi-page work, conditional asset control, or AI-assisted Auto Fix is needed.', 'ndsoft-speed-doctor' ); ?></p>
                </div>
            <?php endif; ?>
        </section>

        <h2 class="ndssd-section-title"><?php esc_html_e( 'One-Click Safe Fix Center', 'ndsoft-speed-doctor' ); ?></h2>
        <section class="ndssd-card ndssd-fix-center">
            <div class="ndssd-fix-center-head">
                <div>
                    <h2><?php esc_html_e( 'Safe Fix Engine', 'ndsoft-speed-doctor' ); ?></h2>
                    <p><?php esc_html_e( 'Every one-click fix creates a snapshot, purges compatible caches, and runs a frontend health check. Failed health checks are automatically rolled back.', 'ndsoft-speed-doctor' ); ?></p>
                </div>
                <span class="ndssd-edition-badge <?php echo esc_attr( $edition ); ?>"><?php echo esc_html( strtoupper( $edition ) ); ?></span>
            </div>

            <div class="ndssd-fix-toolbar">
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <input type="hidden" name="action" value="ndssd_apply_all_safe">
                    <?php wp_nonce_field( 'ndssd_apply_all_safe' ); ?>
                    <?php submit_button( __( 'Apply All Available Safe Fixes', 'ndsoft-speed-doctor' ), 'primary', 'submit', false ); ?>
                </form>
                <?php if ( $has_fix_snapshot ) : ?>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="ndssd_rollback_last_fix">
                        <?php wp_nonce_field( 'ndssd_rollback_last_fix' ); ?>
                        <?php submit_button( __( 'Roll Back Last One-Click Fix', 'ndsoft-speed-doctor' ), 'secondary', 'submit', false ); ?>
                    </form>
                <?php endif; ?>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <input type="hidden" name="action" value="ndssd_verify_latest_fix">
                    <?php wp_nonce_field( 'ndssd_verify_latest_fix' ); ?>
                    <?php submit_button( __( 'Verify Fix — Fresh PageSpeed Scan', 'ndsoft-speed-doctor' ), 'secondary', 'submit', false ); ?>
                </form>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <input type="hidden" name="action" value="ndssd_purge_cache">
                    <?php wp_nonce_field( 'ndssd_purge_cache' ); ?>
                    <?php submit_button( __( 'Purge Compatible Caches', 'ndsoft-speed-doctor' ), 'secondary', 'submit', false ); ?>
                </form>
            </div>

            <div class="ndssd-safe-fix-grid">
                <?php foreach ( $fixes as $fix ) : ?>
                    <article class="ndssd-safe-fix-card <?php echo ! empty( $fix['active'] ) ? 'active' : ''; ?>">
                        <div class="ndssd-safe-fix-title">
                            <h3><?php echo esc_html( $fix['label'] ); ?></h3>
                            <span class="ndssd-risk low"><?php esc_html_e( 'Low risk', 'ndsoft-speed-doctor' ); ?></span>
                        </div>
                        <p><?php echo esc_html( $fix['description'] ); ?></p>
                        <?php if ( 'lcp_priority' === $fix['id'] && ! empty( $fix['target'] ) ) : ?>
                            <code class="ndssd-break"><?php echo esc_html( $fix['target'] ); ?></code>
                        <?php endif; ?>
                        <?php if ( ! empty( $fix['active'] ) ) : ?>
                            <p class="ndssd-good-text">✓ <?php esc_html_e( 'Active', 'ndsoft-speed-doctor' ); ?></p>
                            <?php if ( 'lcp_priority' === $fix['id'] ) : ?>
                                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="ndssd_disable_lcp_fix"><?php wp_nonce_field( 'ndssd_disable_lcp_fix' ); ?><?php submit_button( __( 'Disable LCP Fix', 'ndsoft-speed-doctor' ), 'secondary', 'submit', false ); ?></form>
                            <?php endif; ?>
                        <?php elseif ( ! empty( $fix['available'] ) ) : ?>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                                <input type="hidden" name="action" value="ndssd_apply_safe_fix">
                                <input type="hidden" name="fix_id" value="<?php echo esc_attr( $fix['id'] ); ?>">
                                <?php wp_nonce_field( 'ndssd_apply_safe_fix' ); ?>
                                <?php submit_button( __( 'Fix Safely', 'ndsoft-speed-doctor' ), 'primary', 'submit', false ); ?>
                            </form>
                        <?php else : ?>
                            <p class="description"><?php esc_html_e( 'No current scan condition requires this fix.', 'ndsoft-speed-doctor' ); ?></p>
                        <?php endif; ?>
                    </article>
                <?php endforeach; ?>
            </div>

            <?php $missing = ! empty( $local_analysis['images_missing_dimensions'] ) ? $local_analysis['images_missing_dimensions'] : array(); ?>
            <?php if ( $missing ) : ?>
                <details class="ndssd-inline-details">
                    <summary><?php echo esc_html( sprintf( _n( 'Show %d image dimension finding', 'Show %d image dimension findings', count( $missing ), 'ndsoft-speed-doctor' ), count( $missing ) ) ); ?></summary>
                    <div class="ndssd-resource-list">
                        <?php foreach ( array_slice( $missing, 0, 8 ) as $image ) : ?>
                            <div class="ndssd-resource"><code><?php echo esc_html( $image['src'] ); ?></code><small><?php echo ! empty( $image['fixable'] ) ? esc_html( $image['suggested_width'] . '×' . $image['suggested_height'] . ' available' ) : esc_html__( 'Dimensions unavailable automatically', 'ndsoft-speed-doctor' ); ?></small></div>
                        <?php endforeach; ?>
                    </div>
                </details>
            <?php endif; ?>
        </section>

        <?php do_action( 'ndssd_render_pro_dashboard' ); ?>

        <?php if ( ! empty( $previous_results ) ) : ?>
            <h2 class="ndssd-section-title"><?php esc_html_e( 'Before vs After', 'ndsoft-speed-doctor' ); ?></h2>
            <section class="ndssd-card">
                <p class="description"><?php esc_html_e( 'Compares the latest scan with the immediately previous saved scan. For a valid optimization comparison, use Force fresh scan after clearing page/CDN cache.', 'ndsoft-speed-doctor' ); ?></p>
                <div class="ndssd-comparison-wrap">
                    <table class="widefat striped ndssd-comparison">
                        <thead><tr><th><?php esc_html_e( 'Device / metric', 'ndsoft-speed-doctor' ); ?></th><th><?php esc_html_e( 'Before', 'ndsoft-speed-doctor' ); ?></th><th><?php esc_html_e( 'After', 'ndsoft-speed-doctor' ); ?></th><th><?php esc_html_e( 'Change', 'ndsoft-speed-doctor' ); ?></th></tr></thead>
                        <tbody>
                        <?php foreach ( array( 'mobile', 'desktop' ) as $strategy ) : ?>
                            <?php if ( empty( $results[ $strategy ] ) || empty( $previous_results[ $strategy ] ) ) { continue; } ?>
                            <tr><th><?php echo esc_html( ucfirst( $strategy ) . ' score' ); ?></th><td><?php echo esc_html( $previous_results[ $strategy ]['performance'] ); ?></td><td><?php echo esc_html( $results[ $strategy ]['performance'] ); ?></td><td><?php echo wp_kses_post( ndssd_delta_label( (float) $results[ $strategy ]['performance'], (float) $previous_results[ $strategy ]['performance'], true, '' ) ); ?></td></tr>
                            <?php foreach ( array( 'largest-contentful-paint' => 'LCP', 'speed-index' => 'Speed Index', 'total-blocking-time' => 'TBT', 'cumulative-layout-shift' => 'CLS' ) as $metric_id => $label ) : ?>
                                <?php $cur = ndssd_metric_numeric( $results[ $strategy ], $metric_id ); $prev = ndssd_metric_numeric( $previous_results[ $strategy ], $metric_id ); ?>
                                <?php if ( null === $cur || null === $prev ) { continue; } ?>
                                <?php $delta_suffix = 'cumulative-layout-shift' === $metric_id ? '' : ' ms'; ?>
                                <tr><th><?php echo esc_html( ucfirst( $strategy ) . ' ' . $label ); ?></th><td><?php echo esc_html( $previous_results[ $strategy ]['lab'][ $metric_id ]['display_value'] ); ?></td><td><?php echo esc_html( $results[ $strategy ]['lab'][ $metric_id ]['display_value'] ); ?></td><td><?php echo wp_kses_post( ndssd_delta_label( $cur, $prev, false, $delta_suffix ) ); ?></td></tr>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        <?php endif; ?>
    <?php endif; ?>

    <h2 class="ndssd-section-title"><?php esc_html_e( '2. Safe Optimization Controls', 'ndsoft-speed-doctor' ); ?></h2>
    <section class="ndssd-card">
        <?php if ( ! empty( $environment['litespeed_active'] ) ) : ?>
            <div class="ndssd-warning-box"><strong><?php esc_html_e( 'LiteSpeed Cache is active.', 'ndsoft-speed-doctor' ); ?></strong> <?php esc_html_e( 'Keep overlapping JS/CSS optimization disabled here unless you intentionally test one system at a time. After HTML-level changes, purge LiteSpeed/page cache before verification.', 'ndsoft-speed-doctor' ); ?></div>
        <?php endif; ?>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="ndssd_save_settings">
            <?php wp_nonce_field( 'ndssd_save_settings' ); ?>

            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="ndssd-api-key"><?php esc_html_e( 'PageSpeed API key', 'ndsoft-speed-doctor' ); ?></label></th>
                    <td>
                        <input id="ndssd-api-key" class="regular-text" type="password" name="api_key" value="" autocomplete="new-password" placeholder="<?php echo $api_configured ? esc_attr__( 'Configured — enter a new key only to replace it', 'ndsoft-speed-doctor' ) : esc_attr__( 'Paste API key', 'ndsoft-speed-doctor' ); ?>">
                        <p class="description"><?php echo $api_configured ? esc_html__( 'The active key is masked and is not rendered back into the page HTML.', 'ndsoft-speed-doctor' ) : esc_html__( 'Add a PageSpeed Insights API key for reliable quota.', 'ndsoft-speed-doctor' ); ?> <?php esc_html_e( 'Current source:', 'ndsoft-speed-doctor' ); ?> <code><?php echo esc_html( $pagespeed_key_source ); ?></code>. <?php esc_html_e( 'For production you may define NDSSD_PAGESPEED_API_KEY in wp-config.php.', 'ndsoft-speed-doctor' ); ?></p>
                        <?php if ( ! empty( $settings['api_key'] ) ) : ?><label><input type="checkbox" name="clear_api_key" value="1"> <?php esc_html_e( 'Remove saved API key', 'ndsoft-speed-doctor' ); ?></label><?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="ndssd-cache-minutes"><?php esc_html_e( 'PageSpeed result cache', 'ndsoft-speed-doctor' ); ?></label></th>
                    <td><input id="ndssd-cache-minutes" type="number" min="5" max="1440" name="cache_minutes" value="<?php echo esc_attr( (int) $settings['cache_minutes'] ); ?>"> <?php esc_html_e( 'minutes', 'ndsoft-speed-doctor' ); ?><p class="description"><?php esc_html_e( 'Repeated scans can reuse cached PSI results unless Force fresh scan is selected.', 'ndsoft-speed-doctor' ); ?></p></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e( 'Disable WordPress emoji assets', 'ndsoft-speed-doctor' ); ?></th>
                    <td><label><input type="checkbox" name="disable_emojis" value="1" <?php checked( ! empty( $settings['disable_emojis'] ) ); ?>> <?php esc_html_e( 'Remove legacy emoji detection JS/CSS from frontend output.', 'ndsoft-speed-doctor' ); ?></label></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e( 'Fix local image width/height', 'ndsoft-speed-doctor' ); ?></th>
                    <td><label><input type="checkbox" name="fix_local_image_dimensions" value="1" <?php checked( ! empty( $settings['fix_local_image_dimensions'] ) ); ?>> <?php esc_html_e( 'Add missing width/height only when Speed Doctor can read the exact local image file dimensions.', 'ndsoft-speed-doctor' ); ?></label><p class="description"><?php esc_html_e( 'This is an HTML-output fix; test responsive layouts after enabling.', 'ndsoft-speed-doctor' ); ?></p></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e( 'Generic first-content image priority', 'ndsoft-speed-doctor' ); ?></th>
                    <td><label><input type="checkbox" name="content_image_priority" value="1" <?php checked( ! empty( $settings['content_image_priority'] ) ); ?>> <?php esc_html_e( 'Prioritize the first image inside post/page content.', 'ndsoft-speed-doctor' ); ?></label><p class="description"><?php esc_html_e( 'Leave off when the exact LCP detector is available; the targeted LCP fix is safer.', 'ndsoft-speed-doctor' ); ?></p></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e( 'Preload featured image', 'ndsoft-speed-doctor' ); ?></th>
                    <td><label><input type="checkbox" name="preload_featured_image" value="1" <?php checked( ! empty( $settings['preload_featured_image'] ) ); ?>> <?php esc_html_e( 'Adds an image preload hint on singular pages with a featured image.', 'ndsoft-speed-doctor' ); ?></label><p class="description"><?php esc_html_e( 'Use only if the featured image is above the fold and actually critical.', 'ndsoft-speed-doctor' ); ?></p></td>
                </tr>
                <tr>
                    <th scope="row"><label for="ndssd-defer-handles"><?php esc_html_e( 'Defer selected script handles', 'ndsoft-speed-doctor' ); ?></label></th>
                    <td><textarea id="ndssd-defer-handles" class="large-text code" rows="3" name="defer_script_handles" placeholder="example-handle, another-handle"><?php echo esc_textarea( $settings['defer_script_handles'] ); ?></textarea><p class="description"><?php esc_html_e( 'Advanced. Add WordPress script handles only after dependency testing. Leave blank when LiteSpeed/WP Rocket already manages JS.', 'ndsoft-speed-doctor' ); ?></p></td>
                </tr>
            </table>

            <?php submit_button( __( 'Save Optimization Settings', 'ndsoft-speed-doctor' ) ); ?>
        </form>

        <hr>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="ndssd_restore_settings">
            <?php wp_nonce_field( 'ndssd_restore_settings' ); ?>
            <?php submit_button( __( 'Restore Previous Settings', 'ndsoft-speed-doctor' ), 'secondary', 'submit', false ); ?>
            <span class="description ndssd-inline-note"><?php esc_html_e( 'Swaps the current settings with the previous saved snapshot.', 'ndsoft-speed-doctor' ); ?></span>
        </form>
    </section>

    <?php do_action( 'ndssd_render_pro_settings' ); ?>

    <h2 class="ndssd-section-title"><?php esc_html_e( '3. Support & Release Readiness', 'ndsoft-speed-doctor' ); ?></h2>
    <section class="ndssd-card">
        <div class="ndssd-fix-center-head">
            <div>
                <h2><?php esc_html_e( 'Sanitized system report', 'ndsoft-speed-doctor' ); ?></h2>
                <p><?php esc_html_e( 'Export a support report with versions, compatibility status, key sources, non-secret integration settings, and latest scan summary. API keys and bearer tokens are never included.', 'ndsoft-speed-doctor' ); ?></p>
            </div>
            <span class="ndssd-badge">v<?php echo esc_html( NDSSD_VERSION ); ?></span>
        </div>
        <div class="ndssd-status-grid">
            <div><span><?php esc_html_e( 'Theme', 'ndsoft-speed-doctor' ); ?></span><strong><?php echo esc_html( ! empty( $system_report['theme']['name'] ) ? $system_report['theme']['name'] : '—' ); ?></strong></div>
            <div><span><?php esc_html_e( 'HTTPS', 'ndsoft-speed-doctor' ); ?></span><strong><?php echo ! empty( $system_report['site']['https'] ) ? esc_html__( 'Yes', 'ndsoft-speed-doctor' ) : esc_html__( 'No', 'ndsoft-speed-doctor' ); ?></strong></div>
            <div><span><?php esc_html_e( 'Object cache', 'ndsoft-speed-doctor' ); ?></span><strong><?php echo ! empty( $system_report['runtime']['object_cache'] ) ? esc_html__( 'Active', 'ndsoft-speed-doctor' ) : esc_html__( 'Not detected', 'ndsoft-speed-doctor' ); ?></strong></div>
            <div><span><?php esc_html_e( 'Local image findings', 'ndsoft-speed-doctor' ); ?></span><strong><?php echo esc_html( isset( $system_report['local_analysis']['missing_dimension_count'] ) ? $system_report['local_analysis']['missing_dimension_count'] : 0 ); ?></strong></div>
        </div>
        <div class="ndssd-actions">
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="ndssd_export_system_report">
                <?php wp_nonce_field( 'ndssd_export_system_report' ); ?>
                <?php submit_button( __( 'Download System Report (.json)', 'ndsoft-speed-doctor' ), 'secondary', 'submit', false ); ?>
            </form>
        </div>
    </section>

    <?php if ( ! empty( $history ) ) : ?>
        <section class="ndssd-card ndssd-history-card">
            <h2><?php esc_html_e( 'Recent scan history', 'ndsoft-speed-doctor' ); ?></h2>
            <div class="ndssd-history">
                <?php foreach ( array_reverse( array_slice( $history, -6 ) ) as $entry ) : ?>
                    <div><span><?php echo esc_html( $entry['created_at'] ); ?></span><strong>M <?php echo isset( $entry['mobile']['performance'] ) ? esc_html( $entry['mobile']['performance'] ) : '—'; ?> · D <?php echo isset( $entry['desktop']['performance'] ) ? esc_html( $entry['desktop']['performance'] ) : '—'; ?></strong></div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if ( ! empty( $fix_history ) ) : ?>
        <section class="ndssd-card ndssd-history-card">
            <h2><?php esc_html_e( 'One-Click Fix History', 'ndsoft-speed-doctor' ); ?></h2>
            <div class="ndssd-fix-history">
                <?php foreach ( array_reverse( array_slice( $fix_history, -6 ) ) as $entry ) : ?>
                    <div class="ndssd-fix-history-row">
                        <div><strong><?php echo esc_html( ! empty( $entry['fix_id'] ) ? $entry['fix_id'] : 'fix' ); ?></strong><span><?php echo esc_html( ! empty( $entry['created_at'] ) ? $entry['created_at'] : '' ); ?></span></div>
                        <span class="ndssd-fix-status <?php echo esc_attr( ! empty( $entry['status'] ) ? $entry['status'] : 'info' ); ?>"><?php echo esc_html( ! empty( $entry['status'] ) ? ucwords( str_replace( '-', ' ', $entry['status'] ) ) : '—' ); ?></span>
                        <small><?php echo esc_html( ! empty( $entry['message'] ) ? $entry['message'] : '' ); ?></small>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="ndssd-card ndssd-roadmap">
        <h2><?php esc_html_e( 'v0.9.0-beta4 Free status', 'ndsoft-speed-doctor' ); ?></h2>
        <p><strong><?php esc_html_e( 'Included:', 'ndsoft-speed-doctor' ); ?></strong> <?php esc_html_e( 'Free beta includes PageSpeed diagnostics, compatibility detection, asset probing, real low-risk one-click fixes, cache-aware verification, and frontend structural regression rollback. Premium execution code ships only in the separate Pro add-on.', 'ndsoft-speed-doctor' ); ?></p>
        <p><strong><?php esc_html_e( 'Intentionally diagnostic-only for now:', 'ndsoft-speed-doctor' ); ?></strong> <?php esc_html_e( 'AI-assisted Auto Fix, conditional asset unloading, licensing, and future hosted AI credits are provided by the separate Pro add-on and are being validated before stable 1.0.', 'ndsoft-speed-doctor' ); ?></p>
    </section>
</div>
