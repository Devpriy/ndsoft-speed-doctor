<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class NDSSD_Admin {
    public function __construct() {
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'admin_post_ndssd_run_scan', array( $this, 'run_scan' ) );
        add_action( 'admin_post_ndssd_save_settings', array( $this, 'save_settings' ) );
        add_action( 'admin_post_ndssd_restore_settings', array( $this, 'restore_settings' ) );
        add_action( 'admin_post_ndssd_apply_lcp_fix', array( $this, 'apply_lcp_fix' ) );
        add_action( 'admin_post_ndssd_disable_lcp_fix', array( $this, 'disable_lcp_fix' ) );
        add_action( 'admin_post_ndssd_clear_scan_cache', array( $this, 'clear_scan_cache' ) );
        add_action( 'admin_post_ndssd_test_api', array( $this, 'test_api' ) );
        add_action( 'admin_post_ndssd_apply_safe_fix', array( $this, 'apply_safe_fix' ) );
        add_action( 'admin_post_ndssd_apply_all_safe', array( $this, 'apply_all_safe' ) );
        add_action( 'admin_post_ndssd_rollback_last_fix', array( $this, 'rollback_last_fix' ) );
        add_action( 'admin_post_ndssd_verify_latest_fix', array( $this, 'verify_latest_fix' ) );
        add_action( 'admin_post_ndssd_purge_cache', array( $this, 'purge_cache' ) );
        add_action( 'admin_post_ndssd_export_system_report', array( $this, 'export_system_report' ) );
        add_action( 'admin_post_ndssd_probe_assets', array( $this, 'probe_assets' ) );
    }

    public function admin_menu() {
        add_menu_page(
            __( 'NDsoft Speed Doctor', 'ndsoft-speed-doctor' ),
            __( 'Speed Doctor', 'ndsoft-speed-doctor' ),
            'manage_options',
            'ndsoft-speed-doctor',
            array( $this, 'render_dashboard' ),
            'dashicons-performance',
            58
        );
    }

    public function enqueue_assets( $hook ) {
        if ( 'toplevel_page_ndsoft-speed-doctor' !== $hook ) {
            return;
        }
        wp_enqueue_style( 'ndssd-admin', NDSSD_URL . 'assets/admin.css', array(), NDSSD_VERSION );
    }

    public function render_dashboard() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $settings         = wp_parse_args( get_option( 'ndssd_settings', array() ), NDSSD_Plugin::defaults() );
        $results          = get_option( 'ndssd_last_scan', array() );
        $previous_results = get_option( 'ndssd_previous_scan', array() );
        $local_analysis   = get_option( 'ndssd_last_local_analysis', array() );
        $environment      = NDSSD_Site_Analyzer::environment();
        $history          = get_option( 'ndssd_scan_history', array() );
        $notice           = isset( $_GET['ndssd_notice'] ) ? sanitize_key( wp_unslash( $_GET['ndssd_notice'] ) ) : '';
        $message          = isset( $_GET['ndssd_message'] ) ? sanitize_text_field( wp_unslash( $_GET['ndssd_message'] ) ) : '';
        $fixes            = NDSSD_Fix_Engine::available_fixes( is_array( $results ) ? $results : array(), is_array( $local_analysis ) ? $local_analysis : array(), $settings );
        $fix_history      = NDSSD_Fix_Engine::history();
        $has_fix_snapshot = NDSSD_Fix_Engine::has_snapshot();
        $edition          = NDSSD_Feature_Manager::edition();
        $pro_features     = NDSSD_Feature_Manager::pro_features();
        $optimization_summary = NDSSD_Feature_Manager::optimization_summary( is_array( $results ) ? $results : array(), is_array( $fixes ) ? $fixes : array() );
        $advanced_opportunities = isset( $optimization_summary['advanced_opportunities'] ) ? $optimization_summary['advanced_opportunities'] : array();
        $upgrade_url      = NDSSD_Feature_Manager::upgrade_url();
        $system_report    = NDSSD_System_Report::build();
        $compatibility_profiles = NDSSD_Compatibility_Manager::profiles();
        $asset_inventory  = get_option( NDSSD_Asset_Inspector::OPTION, array() );
        $asset_inventory  = is_array( $asset_inventory ) ? $asset_inventory : array();
        $asset_probe_error= sanitize_text_field( (string) get_option( 'ndssd_last_asset_probe_error', '' ) );
        include NDSSD_DIR . 'admin/views/dashboard.php';
    }

    public function run_scan() {
        $this->guard( 'ndssd_scan' );
        $url = isset( $_POST['scan_url'] ) ? esc_url_raw( wp_unslash( $_POST['scan_url'] ) ) : home_url( '/' );
        $force = isset( $_POST['force_refresh'] );
        if ( ! $this->is_local_site_url( $url ) ) {
            $this->redirect( 'error', __( 'For safety, Speed Doctor only scans URLs on this WordPress site.', 'ndsoft-speed-doctor' ) );
        }

        $scan = $this->perform_scan( $url, $force, false );
        if ( $scan['errors'] ) {
            $this->redirect( $scan['results'] ? 'warning' : 'error', implode( ' | ', $scan['errors'] ) );
        }
        $this->redirect( 'success', $scan['cached'] ? __( 'Scan loaded successfully. Cached PSI data was reused to save API quota.', 'ndsoft-speed-doctor' ) : __( 'Fresh PageSpeed scan completed.', 'ndsoft-speed-doctor' ) );
    }

    public function save_settings() {
        $this->guard( 'ndssd_save_settings' );

        $old = wp_parse_args( get_option( 'ndssd_settings', array() ), NDSSD_Plugin::defaults() );
        update_option( 'ndssd_previous_settings', $old, false );

        $api_key = $old['api_key'];
        if ( isset( $_POST['clear_api_key'] ) ) {
            $api_key = '';
        } elseif ( isset( $_POST['api_key'] ) && '' !== trim( (string) wp_unslash( $_POST['api_key'] ) ) ) {
            $api_key = sanitize_text_field( wp_unslash( $_POST['api_key'] ) );
        }

        $new = array(
            'api_key'                    => $api_key,
            'cache_minutes'              => isset( $_POST['cache_minutes'] ) ? max( 5, min( 1440, absint( $_POST['cache_minutes'] ) ) ) : 30,
            'disable_emojis'             => isset( $_POST['disable_emojis'] ) ? 1 : 0,
            'content_image_priority'     => isset( $_POST['content_image_priority'] ) ? 1 : 0,
            'preload_featured_image'     => isset( $_POST['preload_featured_image'] ) ? 1 : 0,
            'defer_script_handles'       => isset( $_POST['defer_script_handles'] ) ? sanitize_textarea_field( wp_unslash( $_POST['defer_script_handles'] ) ) : '',
            'exact_lcp_priority'         => ! empty( $old['exact_lcp_priority'] ) ? 1 : 0,
            'exact_lcp_url'              => ! empty( $old['exact_lcp_url'] ) ? esc_url_raw( $old['exact_lcp_url'] ) : '',
            'fix_local_image_dimensions' => isset( $_POST['fix_local_image_dimensions'] ) ? 1 : 0,
            'edition'                    => isset( $old['edition'] ) ? sanitize_key( $old['edition'] ) : 'free',
        );

        update_option( 'ndssd_settings', $new, false );
        NDSSD_Cache_Manager::purge();
        ( new NDSSD_PageSpeed_Client() )->clear_cache( $this->latest_url() );
        $this->redirect( 'success', __( 'Settings saved. Previous settings were kept for rollback and compatible caches were purged.', 'ndsoft-speed-doctor' ) );
    }

    public function restore_settings() {
        $this->guard( 'ndssd_restore_settings' );
        $previous = get_option( 'ndssd_previous_settings', false );
        if ( ! is_array( $previous ) ) {
            $this->redirect( 'warning', __( 'No previous settings snapshot is available yet.', 'ndsoft-speed-doctor' ) );
        }

        $current = wp_parse_args( get_option( 'ndssd_settings', array() ), NDSSD_Plugin::defaults() );
        update_option( 'ndssd_settings', wp_parse_args( $previous, NDSSD_Plugin::defaults() ), false );
        update_option( 'ndssd_previous_settings', $current, false );
        NDSSD_Cache_Manager::purge();
        ( new NDSSD_PageSpeed_Client() )->clear_cache( $this->latest_url() );
        $this->redirect( 'success', __( 'Previous optimization settings restored and compatible caches purged.', 'ndsoft-speed-doctor' ) );
    }

    public function export_system_report() {
        $this->guard( 'ndssd_export_system_report' );
        $report = NDSSD_System_Report::build();
        $filename = 'ndsoft-speed-doctor-system-report-' . gmdate( 'Ymd-His' ) . '.json';
        nocache_headers();
        header( 'Content-Type: application/json; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
        echo wp_json_encode( $report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit;
    }

    public function apply_safe_fix() {
        $this->guard( 'ndssd_apply_safe_fix' );
        $fix_id = isset( $_POST['fix_id'] ) ? sanitize_key( wp_unslash( $_POST['fix_id'] ) ) : '';
        $url = $this->latest_url();
        $engine = new NDSSD_Fix_Engine();
        $result = $engine->apply( $fix_id, $url );
        if ( is_wp_error( $result ) ) {
            $this->redirect( 'error', $result->get_error_message() );
        }
        $label = ! empty( $result['fix']['label'] ) ? $result['fix']['label'] : $fix_id;
        $this->redirect( 'success', sprintf( __( '%s applied. Frontend health check passed. Run Verify Fix for a fresh before/after PageSpeed comparison.', 'ndsoft-speed-doctor' ), $label ) );
    }

    public function apply_all_safe() {
        $this->guard( 'ndssd_apply_all_safe' );
        $engine = new NDSSD_Fix_Engine();
        $result = $engine->apply_all_safe( $this->latest_url() );
        if ( is_wp_error( $result ) ) {
            $this->redirect( 'error', $result->get_error_message() );
        }
        $this->redirect( 'success', sprintf( _n( '%d safe fix applied and frontend health check passed.', '%d safe fixes applied and frontend health check passed.', count( $result['fix_ids'] ), 'ndsoft-speed-doctor' ), count( $result['fix_ids'] ) ) );
    }

    public function rollback_last_fix() {
        $this->guard( 'ndssd_rollback_last_fix' );
        $engine = new NDSSD_Fix_Engine();
        $result = $engine->rollback_last();
        if ( is_wp_error( $result ) ) {
            $this->redirect( 'warning', $result->get_error_message() );
        }
        $this->redirect( 'success', __( 'Last one-click fix snapshot restored and caches purged.', 'ndsoft-speed-doctor' ) );
    }

    public function verify_latest_fix() {
        $this->guard( 'ndssd_verify_latest_fix' );
        $url = $this->latest_url();
        $scan = $this->perform_scan( $url, true, true );
        if ( $scan['errors'] ) {
            $this->redirect( $scan['results'] ? 'warning' : 'error', implode( ' | ', $scan['errors'] ) );
        }
        $this->redirect( 'success', __( 'Fix verification completed with fresh Mobile + Desktop PageSpeed results.', 'ndsoft-speed-doctor' ) );
    }

    public function purge_cache() {
        $this->guard( 'ndssd_purge_cache' );
        $purged = NDSSD_Cache_Manager::purge();
        $message = $purged ? sprintf( __( 'Cache purge requested for: %s.', 'ndsoft-speed-doctor' ), implode( ', ', $purged ) ) : __( 'WordPress cache purge requested.', 'ndsoft-speed-doctor' );
        $this->redirect( 'success', $message );
    }

    public function apply_lcp_fix() {
        $this->guard( 'ndssd_apply_lcp_fix' );
        $engine = new NDSSD_Fix_Engine();
        $result = $engine->apply( 'lcp_priority', $this->latest_url() );
        if ( is_wp_error( $result ) ) {
            $this->redirect( 'warning', $result->get_error_message() );
        }
        $this->redirect( 'success', __( 'Exact LCP image priority fix enabled and frontend health check passed.', 'ndsoft-speed-doctor' ) );
    }

    public function disable_lcp_fix() {
        $this->guard( 'ndssd_disable_lcp_fix' );
        $old = wp_parse_args( get_option( 'ndssd_settings', array() ), NDSSD_Plugin::defaults() );
        update_option( 'ndssd_previous_settings', $old, false );
        $old['exact_lcp_priority'] = 0;
        $old['exact_lcp_url'] = '';
        update_option( 'ndssd_settings', $old, false );
        NDSSD_Cache_Manager::purge();
        ( new NDSSD_PageSpeed_Client() )->clear_cache( $this->latest_url() );
        $this->redirect( 'success', __( 'Exact LCP image priority fix disabled and caches purged.', 'ndsoft-speed-doctor' ) );
    }

    public function clear_scan_cache() {
        $this->guard( 'ndssd_clear_scan_cache' );
        $url = isset( $_POST['scan_url'] ) ? esc_url_raw( wp_unslash( $_POST['scan_url'] ) ) : '';
        $client = new NDSSD_PageSpeed_Client();
        $client->clear_cache( $url );
        $this->redirect( 'success', __( 'Speed Doctor scan cache cleared.', 'ndsoft-speed-doctor' ) );
    }

    public function test_api() {
        $this->guard( 'ndssd_test_api' );
        if ( '' === NDSSD_PageSpeed_Client::api_key() ) {
            $this->redirect( 'warning', __( 'Configure a PageSpeed API key first.', 'ndsoft-speed-doctor' ) );
        }
        $client = new NDSSD_PageSpeed_Client();
        $result = $client->scan( home_url( '/' ), 'mobile', true );
        if ( is_wp_error( $result ) ) {
            $this->redirect( 'error', sprintf( __( 'API test failed: %s', 'ndsoft-speed-doctor' ), $result->get_error_message() ) );
        }
        $score = null === $result['performance'] ? '—' : (string) $result['performance'];
        $this->redirect( 'success', sprintf( __( 'PageSpeed API connection works. Mobile performance score returned: %s.', 'ndsoft-speed-doctor' ), $score ) );
    }

    public function probe_assets() {
        $this->guard( 'ndssd_probe_assets' );
        $result = NDSSD_Asset_Inspector::probe( $this->latest_url() );
        if ( is_wp_error( $result ) ) {
            $this->redirect( 'error', sprintf( __( 'Asset probe failed: %s', 'ndsoft-speed-doctor' ), $result->get_error_message() ) );
        }
        $count = count( isset( $result['styles'] ) ? (array) $result['styles'] : array() ) + count( isset( $result['scripts'] ) ? (array) $result['scripts'] : array() );
        $this->redirect( 'success', sprintf( _n( '%d frontend asset handle captured.', '%d frontend asset handles captured.', $count, 'ndsoft-speed-doctor' ), $count ) );
    }

    private function perform_scan( $url, $force, $mark_verified ) {
        $client = new NDSSD_PageSpeed_Client();
        $results = array();
        $errors = array();
        foreach ( array( 'mobile', 'desktop' ) as $strategy ) {
            $result = $client->scan( $url, $strategy, $force );
            if ( is_wp_error( $result ) ) {
                $errors[] = ucfirst( $strategy ) . ': ' . $result->get_error_message();
            } else {
                $results[ $strategy ] = $result;
            }
        }

        $analyzer = new NDSSD_Site_Analyzer();
        update_option( 'ndssd_last_local_analysis', $analyzer->analyze_url( $url ), false );

        // Asset probing does not use PageSpeed quota. It maps Lighthouse URLs back to WordPress handles.
        $asset_probe = NDSSD_Asset_Inspector::probe( $url );
        if ( is_wp_error( $asset_probe ) ) {
            update_option( 'ndssd_last_asset_probe_error', sanitize_text_field( $asset_probe->get_error_message() ), false );
        } else {
            delete_option( 'ndssd_last_asset_probe_error' );
        }

        $old = get_option( 'ndssd_last_scan', array() );
        if ( $results ) {
            if ( is_array( $old ) && ! empty( $old ) ) {
                update_option( 'ndssd_previous_scan', $old, false );
            }
            update_option( 'ndssd_last_scan', $results, false );
            $this->append_history( $results );
            if ( $mark_verified && is_array( $old ) && ! empty( $old ) ) {
                NDSSD_Fix_Engine::mark_latest_verified( $old, $results );
            }
        }

        $cached = false;
        foreach ( $results as $result ) {
            if ( isset( $result['cache_status'] ) && 'hit' === $result['cache_status'] ) {
                $cached = true;
            }
        }
        return array( 'results' => $results, 'errors' => $errors, 'cached' => $cached );
    }

    private function latest_url() {
        $results = get_option( 'ndssd_last_scan', array() );
        $url = ! empty( $results['mobile']['url'] ) ? $results['mobile']['url'] : ( ! empty( $results['desktop']['url'] ) ? $results['desktop']['url'] : home_url( '/' ) );
        return $this->is_local_site_url( $url ) ? $url : home_url( '/' );
    }

    private function append_history( array $results ) {
        $history = get_option( 'ndssd_scan_history', array() );
        if ( ! is_array( $history ) ) {
            $history = array();
        }
        $history[] = array(
            'created_at' => current_time( 'mysql' ),
            'url'        => ! empty( $results['mobile']['url'] ) ? $results['mobile']['url'] : ( ! empty( $results['desktop']['url'] ) ? $results['desktop']['url'] : '' ),
            'mobile'     => $this->history_snapshot( isset( $results['mobile'] ) ? $results['mobile'] : array() ),
            'desktop'    => $this->history_snapshot( isset( $results['desktop'] ) ? $results['desktop'] : array() ),
        );
        if ( count( $history ) > 12 ) {
            $history = array_slice( $history, -12 );
        }
        update_option( 'ndssd_scan_history', $history, false );
    }

    private function history_snapshot( array $result ) {
        $out = array( 'performance' => isset( $result['performance'] ) ? $result['performance'] : null, 'lab' => array() );
        foreach ( array( 'largest-contentful-paint', 'first-contentful-paint', 'total-blocking-time', 'cumulative-layout-shift', 'speed-index' ) as $id ) {
            if ( isset( $result['lab'][ $id ] ) ) {
                $out['lab'][ $id ] = array(
                    'display_value' => $result['lab'][ $id ]['display_value'],
                    'numeric_value' => $result['lab'][ $id ]['numeric_value'],
                );
            }
        }
        return $out;
    }

    private function guard( $action ) {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to perform this action.', 'ndsoft-speed-doctor' ) );
        }
        check_admin_referer( $action );
    }

    private function is_local_site_url( $url ) {
        $target = wp_parse_url( $url );
        $home   = wp_parse_url( home_url( '/' ) );
        if ( empty( $target['scheme'] ) || empty( $target['host'] ) || empty( $home['host'] ) ) {
            return false;
        }
        if ( ! in_array( strtolower( $target['scheme'] ), array( 'http', 'https' ), true ) ) {
            return false;
        }
        return strtolower( $target['host'] ) === strtolower( $home['host'] );
    }

    private function redirect( $type, $message ) {
        $url = add_query_arg(
            array(
                'page'          => 'ndsoft-speed-doctor',
                'ndssd_notice'  => sanitize_key( $type ),
                'ndssd_message' => $message,
            ),
            admin_url( 'admin.php' )
        );
        wp_safe_redirect( $url );
        exit;
    }
}
