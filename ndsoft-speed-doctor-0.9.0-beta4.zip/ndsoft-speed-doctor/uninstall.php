<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Preserve scan history/settings by default. Future versions can add an explicit
// "remove all data on uninstall" setting before deleting options here.
